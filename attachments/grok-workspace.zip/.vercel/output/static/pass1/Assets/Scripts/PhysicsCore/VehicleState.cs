using MarsMission.Math;

namespace MarsMission.PhysicsCore
{
    /// <summary>
    /// Translational vehicle state in SI units, relative to the primary-body center.
    /// Attitude is intentionally absent in Pass 1.
    /// </summary>
    public sealed class VehicleState
    {
        public const double DryMassKg = 120_000d;
        public const double InitialPropellantMassKg = 1_200_000d;

        public Vector3d Position;
        public Vector3d Velocity;
        public double TotalMassKg;
        public double PropellantMassKg;

        /// <summary>
        /// ∫ |a_thrust| dt, integrated with the same RK4 weights as velocity.
        /// </summary>
        public double ThrustIntegratedDeltaVMps;

        public static VehicleState CreateSeaLevel(PlanetaryEnvironment environment)
        {
            return new VehicleState
            {
                Position = new Vector3d(0d, environment.EquatorialRadiusM, 0d),
                Velocity = Vector3d.Zero,
                PropellantMassKg = InitialPropellantMassKg,
                TotalMassKg = DryMassKg + InitialPropellantMassKg,
                ThrustIntegratedDeltaVMps = 0d
            };
        }

        /// <summary>
        /// Entry interface. +Y is radial. Flight-path angle is from the local horizontal.
        /// </summary>
        public static VehicleState CreateEntry(
            PlanetaryEnvironment environment,
            double altitudeM,
            double speedMps,
            double flightPathDeg,
            double propellantKg)
        {
            double radius = environment.EquatorialRadiusM + altitudeM;
            double gamma = flightPathDeg * System.Math.PI / 180d;
            return new VehicleState
            {
                Position = new Vector3d(0d, radius, 0d),
                Velocity = new Vector3d(speedMps * System.Math.Cos(gamma), speedMps * System.Math.Sin(gamma), 0d),
                PropellantMassKg = propellantKg,
                TotalMassKg = DryMassKg + propellantKg,
                ThrustIntegratedDeltaVMps = 0d
            };
        }

        public VehicleState Clone()
        {
            return new VehicleState
            {
                Position = Position,
                Velocity = Velocity,
                TotalMassKg = TotalMassKg,
                PropellantMassKg = PropellantMassKg,
                ThrustIntegratedDeltaVMps = ThrustIntegratedDeltaVMps
            };
        }
    }
}
