//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Rn28X4G9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D5UPGNKi.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D5UPGNKi.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B5ZxxKKr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
