import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Copy, n as RotateCcw, r as Download } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as CartesianGrid, c as Tooltip, i as Line, n as YAxis, o as ReferenceLine, r as XAxis, s as ResponsiveContainer, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-LFjj-sQp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function compactTick(value) {
	if (!Number.isFinite(value)) return "";
	if (Math.abs(value) >= 100) return Math.round(value).toString();
	return value.toFixed(value >= 10 ? 1 : 2);
}
function ChartTip({ active, payload, label }) {
	if (!active || !payload || payload.length === 0) return null;
	const t = typeof label === "number" ? label : Number(label);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-surface px-3 py-2 font-mono text-xs text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 tabular-nums text-muted",
			children: Number.isFinite(t) ? `t ${t.toFixed(1)} s` : ""
		}), payload.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-4 tabular-nums",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				style: { color: row.color },
				children: row.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.value === void 0 ? "—" : row.name === "Altitude" ? row.value.toFixed(2) : row.value.toFixed(1) })]
		}, row.name))]
	});
}
function timeAxis(data) {
	const last = data.length > 0 ? data[data.length - 1].t : 90;
	if (last <= 90) return {
		end: 90,
		ticks: [
			0,
			30,
			60,
			90
		]
	};
	if (last <= 120) return {
		end: 120,
		ticks: [
			0,
			30,
			60,
			90,
			120
		]
	};
	if (last <= 300) {
		const end = last;
		return {
			end,
			ticks: [
				0,
				60,
				120,
				180,
				240,
				300
			].filter((tick) => tick <= end + 1e-6)
		};
	}
	const step = last > 1200 ? 240 : 120;
	const ticks = [];
	for (let tick = 0; tick < last - .001; tick += step) ticks.push(tick);
	const endTick = Math.round(last);
	if (ticks[ticks.length - 1] !== endTick) ticks.push(endTick);
	return {
		end: last,
		ticks
	};
}
function BurnChart({ data, timeS }) {
	const axis = timeAxis(data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-52 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data,
				margin: {
					top: 8,
					right: 4,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-border)",
						strokeDasharray: "3 3",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "t",
						type: "number",
						domain: [0, axis.end],
						ticks: axis.ticks,
						tickFormatter: (value) => `${value}`,
						stroke: "var(--color-border)",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11,
							fontFamily: "IBM Plex Mono, ui-monospace, monospace"
						},
						tickLine: false,
						axisLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						yAxisId: "alt",
						width: 44,
						tickFormatter: compactTick,
						stroke: "var(--color-border)",
						tick: {
							fill: "var(--color-primary)",
							fontSize: 11,
							fontFamily: "IBM Plex Mono, ui-monospace, monospace"
						},
						tickLine: false,
						axisLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						yAxisId: "spd",
						orientation: "right",
						width: 48,
						tickFormatter: compactTick,
						stroke: "var(--color-border)",
						tick: {
							fill: "var(--color-fg)",
							fontSize: 11,
							fontFamily: "IBM Plex Mono, ui-monospace, monospace"
						},
						tickLine: false,
						axisLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
						yAxisId: "alt",
						x: timeS,
						stroke: "var(--color-primary)",
						strokeDasharray: "3 3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						yAxisId: "alt",
						type: "monotone",
						dataKey: "altKm",
						name: "Altitude",
						stroke: "var(--color-primary)",
						strokeWidth: 2,
						dot: false,
						isAnimationActive: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						yAxisId: "spd",
						type: "monotone",
						dataKey: "speed",
						name: "Speed",
						stroke: "var(--color-fg)",
						strokeWidth: 1.5,
						dot: false,
						isAnimationActive: false
					})
				]
			})
		})
	});
}
/** Standard gravity. Converts Isp to exhaust velocity. Not local gravitational acceleration. */
var G0_MPS2 = 9.80665;
var DRY_MASS_KG = 12e4;
var INITIAL_PROPELLANT_KG = 12e5;
var MAX_VACUUM_THRUST_N = 15e6;
var DRAG_CD = .5;
var EARTH_MU_M3_S2 = 3986004418e5;
var EARTH_RADIUS_M = 6371e3;
var EARTH_RHO0_KG_M3 = 1.225;
var EARTH_SCALE_HEIGHT_M = 8500;
/** Earth J2. Stored for later passes. The Pass 1 verification leaves it off. */
var EARTH_J2 = .00108262668;
var MARS_MU_M3_S2 = 4282837e7;
var MARS_RADIUS_M = 3389500;
var MARS_RHO0_KG_M3 = .02;
var MARS_SCALE_HEIGHT_M = 11100;
var MARS_J2 = .00196045;
/** Mars entry interface. Used only when that start is selected. */
var MARS_ENTRY_ALTITUDE_M = 125e3;
var MARS_ENTRY_SPEED_MPS = 6e3;
var MARS_ENTRY_PROPELLANT_KG = 5e4;
/** Open-loop terminal sequence. Used only when that mode is armed on a Mars entry. */
var TERMINAL_TRIGGER_ALTITUDE_M = 3e3;
var TERMINAL_LANDING_THROTTLE = .6;
var TERMINAL_EARLY_ALTITUDE_M = 5e3;
var TERMINAL_MAX_TIME_S = 2400;
/** Verification cutoff. 60 s of thrust, then ballistic coast. */
var CUTOFF_AT_60_S = {
	tCutoffS: 60,
	propellantRemainingKg: null
};
/** 1 while the engine is commanded on, 0 at and after cutoff. */
function commandThrottle(timeS, propellantKg, cutoff) {
	if (cutoff.tCutoffS !== null && !(timeS < cutoff.tCutoffS)) return 0;
	if (cutoff.propellantRemainingKg !== null && !(propellantKg > cutoff.propellantRemainingKg)) return 0;
	return 1;
}
/**
* Specific mechanical energy, m²/s².
* ε = v²/2 − μ/r when the point-mass field is active. Kinetic only when gravity is off.
*/
function specificMechanicalEnergyM2S2(position, velocity, muM3S2) {
	const kinetic = .5 * velocity.sqrMagnitude;
	if (!(muM3S2 > 0)) return kinetic;
	const radius = position.magnitude;
	if (!(radius > 0)) return kinetic;
	return kinetic - muM3S2 / radius;
}
/** Immutable double-precision 3-vector. IEEE-754 binary64, no single-precision path. */
var Vector3d = class Vector3d {
	static zero = new Vector3d(0, 0, 0);
	static up = new Vector3d(0, 1, 0);
	x;
	y;
	z;
	constructor(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	add(other) {
		return new Vector3d(this.x + other.x, this.y + other.y, this.z + other.z);
	}
	sub(other) {
		return new Vector3d(this.x - other.x, this.y - other.y, this.z - other.z);
	}
	scale(scalar) {
		return new Vector3d(this.x * scalar, this.y * scalar, this.z * scalar);
	}
	dot(other) {
		return this.x * other.x + this.y * other.y + this.z * other.z;
	}
	cross(other) {
		return new Vector3d(this.y * other.z - this.z * other.y, this.z * other.x - this.x * other.z, this.x * other.y - this.y * other.x);
	}
	get sqrMagnitude() {
		return this.x * this.x + this.y * this.y + this.z * this.z;
	}
	get magnitude() {
		return Math.sqrt(this.sqrMagnitude);
	}
	get normalized() {
		const mag = this.magnitude;
		if (!(mag > 0)) return Vector3d.zero;
		return this.scale(1 / mag);
	}
	/** Immutable counterpart of the mutating C# Normalize(). */
	normalize() {
		return this.normalized;
	}
};
var DEG_TO_RAD = Math.PI / 180;
var RAD_TO_DEG = 180 / Math.PI;
var PURE_VERTICAL_PROGRAM = {
	tVerticalS: 0,
	pitchRateDegPerS: 0,
	holdPitchDeg: null
};
/** Verification pitch-over: 20 s vertical, then 1.0 deg/s toward horizontal. */
var DEFAULT_PITCH_PROGRAM = {
	tVerticalS: 20,
	pitchRateDegPerS: 1,
	holdPitchDeg: null
};
/** Signed degrees from inertial +Y toward inertial +X. Zero at and before tVertical. */
function pitchAngleDeg(timeS, program) {
	if (!(timeS > program.tVerticalS)) return 0;
	if (program.holdPitchDeg !== null) return program.holdPitchDeg;
	return program.pitchRateDegPerS * (timeS - program.tVerticalS);
}
/** Unit thrust direction. Exactly Vector3d.up when the commanded angle is 0. */
function thrustDirectionAt(timeS, program) {
	const deg = pitchAngleDeg(timeS, program);
	if (deg === 0) return Vector3d.up;
	const rad = deg * DEG_TO_RAD;
	return new Vector3d(Math.sin(rad), Math.cos(rad), 0);
}
/** Speed perpendicular to the radius vector. Zero on a radial trajectory. */
function horizontalSpeedMps(position, velocity) {
	const radius = position.magnitude;
	if (!(radius > 0)) return 0;
	const radial = velocity.dot(position) / radius;
	const radialVelocity = position.scale(radial / radius);
	return velocity.sub(radialVelocity).magnitude;
}
/**
* Flight-path angle from the local horizontal, degrees.
* +90 is radially outward. At rest this is reported as 90, matching the initial vertical.
*/
function flightPathAngleDeg(position, velocity) {
	const radius = position.magnitude;
	const speed = velocity.magnitude;
	if (!(radius > 0) || !(speed > 0)) return 90;
	const radial = velocity.dot(position) / radius;
	const horizontalSq = speed * speed - radial * radial;
	return Math.atan2(radial, Math.sqrt(horizontalSq > 0 ? horizontalSq : 0)) * RAD_TO_DEG;
}
function createEarthEnvironment(options) {
	return {
		name: "Earth",
		muM3S2: EARTH_MU_M3_S2,
		equatorialRadiusM: EARTH_RADIUS_M,
		seaLevelDensityKgM3: EARTH_RHO0_KG_M3,
		scaleHeightM: EARTH_SCALE_HEIGHT_M,
		j2: options?.includeJ2 ? EARTH_J2 : 0,
		speedOfSoundMps: 340,
		gravityEnabled: options?.gravityEnabled ?? true,
		atmosphereEnabled: options?.atmosphereEnabled ?? true
	};
}
function createMarsEnvironment(options) {
	return {
		name: "Mars",
		muM3S2: MARS_MU_M3_S2,
		equatorialRadiusM: MARS_RADIUS_M,
		seaLevelDensityKgM3: MARS_RHO0_KG_M3,
		scaleHeightM: MARS_SCALE_HEIGHT_M,
		j2: options?.includeJ2 ? MARS_J2 : 0,
		speedOfSoundMps: 240,
		gravityEnabled: options?.gravityEnabled ?? true,
		atmosphereEnabled: options?.atmosphereEnabled ?? true
	};
}
/** Altitude above the spherical surface. Negative inside the body. */
function altitudeM(env, position) {
	return position.magnitude - env.equatorialRadiusM;
}
/**
* Exponential atmosphere ρ = ρ0 exp(−h / H).
* Height is clamped at zero so a numerical dip under the surface does not blow the density up.
* Disabled atmosphere returns 0.
*/
function atmosphericDensityKgM3(env, position) {
	if (!env.atmosphereEnabled) return 0;
	const height = Math.max(0, altitudeM(env, position));
	return env.seaLevelDensityKgM3 * Math.exp(-height / env.scaleHeightM);
}
/**
* Point-mass acceleration −μ r / |r|³, plus the J2 zonal term when j2 ≠ 0.
* a_J2 = −(3/2) J2 μ Re² / r⁵ · [(1 − 5 z²/r²) r + 2 z z-hat]
* Returns the zero vector when gravity is disabled or the position is the origin.
*/
function gravitationalAcceleration(env, position) {
	if (!env.gravityEnabled) return Vector3d.zero;
	const r2 = position.sqrMagnitude;
	const r = Math.sqrt(r2);
	if (!(r > 0)) return Vector3d.zero;
	const r3 = r2 * r;
	let accel = position.scale(-env.muM3S2 / r3);
	if (env.j2 !== 0) {
		const fiveZ2OverR2 = 5 * (position.z * position.z) / r2;
		const factor = -1.5 * env.j2 * env.muM3S2 * env.equatorialRadiusM * env.equatorialRadiusM / (r3 * r2);
		accel = accel.add(new Vector3d(factor * position.x * (1 - fiveZ2OverR2), factor * position.y * (1 - fiveZ2OverR2), factor * position.z * (3 - fiveZ2OverR2)));
	}
	return accel;
}
function createDefaultPropulsion() {
	return {
		maxVacuumThrustN: MAX_VACUUM_THRUST_N,
		vacuumIspS: 380,
		g0Mps2: G0_MPS2,
		dragCd: DRAG_CD,
		dragAreaM2: 60,
		thrustDirectionInertial: Vector3d.up
	};
}
function exhaustVelocityMps(model) {
	return model.vacuumIspS * model.g0Mps2;
}
/**
* Positive propellant consumption dm/dt = T / (Isp · g0).
* Zero when the throttle is closed or the tanks are empty.
* A tiny negative propellant (RK4 stage probe landing on the burnout boundary)
* is still treated as firing so the stage derivative stays consistent.
*/
function isFiring(throttle, propellantKg) {
	return throttle > 0 && propellantKg > -1e-8;
}
function thrustMagnitudeN(model, throttle, propellantKg) {
	if (!isFiring(throttle, propellantKg)) return 0;
	return (throttle > 1 ? 1 : throttle) * model.maxVacuumThrustN;
}
function massFlowKgS(model, throttle, propellantKg) {
	const thrust = thrustMagnitudeN(model, throttle, propellantKg);
	if (thrust <= 0) return 0;
	return thrust / exhaustVelocityMps(model);
}
/** Ideal rocket equation. Δv = Isp · g0 · ln(m0 / mf). */
function idealRocketDeltaVMps(model, initialMassKg, finalMassKg) {
	if (!(initialMassKg > 0) || !(finalMassKg > 0) || finalMassKg > initialMassKg) throw new Error("Rocket equation requires 0 < mf ≤ m0.");
	return exhaustVelocityMps(model) * Math.log(initialMassKg / finalMassKg);
}
function createSeaLevelState(env) {
	return {
		position: new Vector3d(0, env.equatorialRadiusM, 0),
		velocity: Vector3d.zero,
		totalMassKg: DRY_MASS_KG + INITIAL_PROPELLANT_KG,
		propellantMassKg: INITIAL_PROPELLANT_KG,
		thrustIntegratedDeltaVMps: 0
	};
}
/** 125 km, 6000 m/s, −12°. Engines are not part of the state. */
var MARS_ENTRY_INTERFACE = {
	altitudeM: MARS_ENTRY_ALTITUDE_M,
	speedMps: MARS_ENTRY_SPEED_MPS,
	flightPathDeg: -12,
	propellantKg: MARS_ENTRY_PROPELLANT_KG
};
/** Same object as the verified interface when the three knobs are at their defaults. */
function marsEntryOrDefault(speedMps, propellantKg, flightPathDeg) {
	if (speedMps === 6e3 && propellantKg === 5e4 && flightPathDeg === -12) return MARS_ENTRY_INTERFACE;
	return {
		altitudeM: MARS_ENTRY_ALTITUDE_M,
		speedMps,
		flightPathDeg,
		propellantKg
	};
}
/**
* Inertial entry state on the active body.
* Position is along +Y at R + h. Velocity is in the XY plane.
* Flight-path angle is from the local horizontal, negative downward.
*/
function createEntryState(env, entry = MARS_ENTRY_INTERFACE) {
	const radius = env.equatorialRadiusM + entry.altitudeM;
	const gamma = entry.flightPathDeg * Math.PI / 180;
	return {
		position: new Vector3d(0, radius, 0),
		velocity: new Vector3d(entry.speedMps * Math.cos(gamma), entry.speedMps * Math.sin(gamma), 0),
		totalMassKg: DRY_MASS_KG + entry.propellantKg,
		propellantMassKg: entry.propellantKg,
		thrustIntegratedDeltaVMps: 0
	};
}
function cloneState(state) {
	return {
		position: state.position,
		velocity: state.velocity,
		totalMassKg: state.totalMassKg,
		propellantMassKg: state.propellantMassKg,
		thrustIntegratedDeltaVMps: state.thrustIntegratedDeltaVMps
	};
}
function massFromPropellant(propellantKg) {
	return DRY_MASS_KG + Math.max(propellantKg, 0);
}
/**
* Translational forces at a state.
* a = g(r) + T/m + D/m
* D = −v̂ · (½ ρ v² Cd A), ρ = ρ0 exp(−h/H), no wind, non-rotating atmosphere.
*/
function evaluateForces(position, velocity, propellantKg, env, propulsion, throttle, thrustDirection) {
	const massKg = massFromPropellant(propellantKg);
	const height = altitudeM(env, position);
	const gravityAccel = gravitationalAcceleration(env, position);
	const density = atmosphericDensityKgM3(env, position);
	const speed = velocity.magnitude;
	const dynamicPressurePa = .5 * density * speed * speed;
	let dragN = 0;
	let dragAccel = Vector3d.zero;
	if (speed > 0 && density > 0 && propulsion.dragCd > 0 && propulsion.dragAreaM2 > 0) {
		dragN = dynamicPressurePa * propulsion.dragCd * propulsion.dragAreaM2;
		dragAccel = velocity.scale(-dragN / (speed * massKg));
	}
	const thrustN = thrustMagnitudeN(propulsion, throttle, propellantKg);
	const thrustAccel = (thrustDirection ?? propulsion.thrustDirectionInertial).scale(thrustN / massKg);
	const acceleration = gravityAccel.add(thrustAccel).add(dragAccel);
	return {
		altitudeM: height,
		massKg,
		acceleration,
		accelerationMagnitudeMps2: acceleration.magnitude,
		thrustN,
		thrustAccelMps2: massKg > 0 ? thrustN / massKg : 0,
		dragN,
		dragAccel,
		gravityMps2: gravityAccel.magnitude,
		gravityAccel,
		densityKgM3: density,
		dynamicPressurePa,
		massFlowKgS: massFlowKgS(propulsion, throttle, propellantKg)
	};
}
function derivative(state, env, propulsion, throttle, thrustDirection) {
	const force = evaluateForces(state.position, state.velocity, state.propellantMassKg, env, propulsion, throttle, thrustDirection);
	return {
		dr: state.velocity,
		dv: force.acceleration,
		dPropellant: -force.massFlowKgS,
		dThrustDeltaV: force.thrustAccelMps2
	};
}
function advance(state, deriv, h) {
	const propellant = state.propellantMassKg + deriv.dPropellant * h;
	return {
		position: state.position.add(deriv.dr.scale(h)),
		velocity: state.velocity.add(deriv.dv.scale(h)),
		propellantMassKg: propellant,
		totalMassKg: massFromPropellant(propellant),
		thrustIntegratedDeltaVMps: state.thrustIntegratedDeltaVMps + deriv.dThrustDeltaV * h
	};
}
function sumDeriv(a, b) {
	return {
		dr: a.dr.add(b.dr),
		dv: a.dv.add(b.dv),
		dPropellant: a.dPropellant + b.dPropellant,
		dThrustDeltaV: a.dThrustDeltaV + b.dThrustDeltaV
	};
}
function scaleDeriv(d, s) {
	return {
		dr: d.dr.scale(s),
		dv: d.dv.scale(s),
		dPropellant: d.dPropellant * s,
		dThrustDeltaV: d.dThrustDeltaV * s
	};
}
function rk4(state, dt, env, propulsion, throttle, thrustDirection) {
	const k1 = derivative(state, env, propulsion, throttle, thrustDirection);
	const k2 = derivative(advance(state, k1, dt * .5), env, propulsion, throttle, thrustDirection);
	const k3 = derivative(advance(state, k2, dt * .5), env, propulsion, throttle, thrustDirection);
	const k4 = derivative(advance(state, k3, dt), env, propulsion, throttle, thrustDirection);
	const next = advance(state, scaleDeriv(sumDeriv(k1, sumDeriv(scaleDeriv(k2, 2), sumDeriv(scaleDeriv(k3, 2), k4))), 1 / 6), dt);
	if (next.propellantMassKg < 0) {
		next.propellantMassKg = 0;
		next.totalMassKg = DRY_MASS_KG;
	} else next.totalMassKg = massFromPropellant(next.propellantMassKg);
	return next;
}
function stepOne(state, dt, env, propulsion, throttle, thrustDirection) {
	if (!(dt > 0)) return state;
	if (state.propellantMassKg <= 0 || !(throttle > 0)) {
		const coast = cloneState(state);
		coast.propellantMassKg = Math.max(0, coast.propellantMassKg);
		coast.totalMassKg = massFromPropellant(coast.propellantMassKg);
		return rk4(coast, dt, env, propulsion, 0, thrustDirection);
	}
	const mdot = massFlowKgS(propulsion, throttle, state.propellantMassKg);
	if (mdot > 0 && state.propellantMassKg < mdot * dt) {
		const dtBurn = state.propellantMassKg / mdot;
		let burned = state;
		if (dtBurn > 0) burned = rk4(state, dtBurn, env, propulsion, throttle, thrustDirection);
		burned.propellantMassKg = 0;
		burned.totalMassKg = DRY_MASS_KG;
		const dtCoast = dt - dtBurn;
		if (dtCoast > 1e-12) return rk4(burned, dtCoast, env, propulsion, 0, thrustDirection);
		return burned;
	}
	return rk4(state, dt, env, propulsion, throttle, thrustDirection);
}
/**
* Advance the vehicle by `dt` seconds using `substeps` equal RK4 sub-steps.
* Sub-steps are optional. The Pass 1 major step is 0.02 s with substeps = 1.
* Mutates nothing: returns the next state.
*/
function stepRk4(state, dt, substeps, env, propulsion, throttle, thrustDirection) {
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const h = dt / substeps;
	let next = state;
	for (let i = 0; i < substeps; i++) next = stepOne(next, h, env, propulsion, isFiring(throttle, next.propellantMassKg) ? throttle : 0, thrustDirection);
	return next;
}
/**
* Classical elements from an inertial state.
* α = 2/r − v²/μ, a = 1/α, e = |((v×h)/μ) − r̂|.
*/
function keplerElements(position, velocity, muM3S2) {
	const radius = position.magnitude;
	const speedSq = velocity.sqrMagnitude;
	const energy = .5 * speedSq - (muM3S2 > 0 && radius > 0 ? muM3S2 / radius : 0);
	if (!(muM3S2 > 0) || !(radius > 0)) return {
		semiMajorAxisM: Number.POSITIVE_INFINITY,
		eccentricity: 0,
		specificEnergyM2S2: energy,
		alphaPerM: 0
	};
	const alpha = 2 / radius - speedSq / muM3S2;
	const semiMajorAxisM = Math.abs(alpha) < 1e-14 ? Number.POSITIVE_INFINITY : 1 / alpha;
	const h = position.cross(velocity);
	return {
		semiMajorAxisM,
		eccentricity: velocity.cross(h).scale(1 / muM3S2).sub(position.scale(1 / radius)).magnitude,
		specificEnergyM2S2: energy,
		alphaPerM: Math.abs(alpha) < 1e-14 ? 0 : alpha
	};
}
/** Stumpff C(z). Series near zero so a short coast does not cancel. */
function stumpffC(z) {
	if (z > 1e-4) return (1 - Math.cos(Math.sqrt(z))) / z;
	if (z < -1e-4) {
		const s = Math.sqrt(-z);
		return (Math.cosh(s) - 1) / -z;
	}
	return .5 - z / 24 + z * z / 720 - z * z * z / 40320;
}
/** Stumpff S(z). */
function stumpffS(z) {
	if (z > 1e-4) {
		const s = Math.sqrt(z);
		return (s - Math.sin(s)) / (s * s * s);
	}
	if (z < -1e-4) {
		const s = Math.sqrt(-z);
		return (Math.sinh(s) - s) / (s * s * s);
	}
	return 1 / 6 - z / 120 + z * z / 5040 - z * z * z / 362880;
}
/**
* Universal-variable Kepler propagation (Battin / Vallado).
* Ellipse, parabola, and hyperbola. dt = 0 returns the captured state.
* μ ≤ 0 is uniform rectilinear motion: no gravity, no drag.
*/
function propagateKepler(position, velocity, muM3S2, dtS) {
	if (!(dtS !== 0)) return {
		position,
		velocity
	};
	if (!(muM3S2 > 0)) return {
		position: position.add(velocity.scale(dtS)),
		velocity
	};
	const radius = position.magnitude;
	const speedSq = velocity.sqrMagnitude;
	const radialRate = position.dot(velocity);
	const sqrtMu = Math.sqrt(muM3S2);
	const alpha = 2 / radius - speedSq / muM3S2;
	let chi = initialChi(alpha, radius, radialRate, muM3S2, dtS, sqrtMu);
	for (let i = 0; i < 40; i++) {
		const z = alpha * chi * chi;
		const c = stumpffC(z);
		const s = stumpffS(z);
		const residual = radialRate / sqrtMu * chi * chi * c + (1 - alpha * radius) * chi * chi * chi * s + radius * chi - sqrtMu * dtS;
		const derivative = radialRate / sqrtMu * chi * (1 - z * s) + (1 - alpha * radius) * chi * chi * c + radius;
		if (!(Math.abs(derivative) > 0)) break;
		const ratio = residual / derivative;
		chi -= ratio;
		if (Math.abs(ratio) < 1e-12) break;
	}
	const z = alpha * chi * chi;
	const c = stumpffC(z);
	const s = stumpffS(z);
	const f = 1 - chi * chi * c / radius;
	const g = dtS - chi * chi * chi * s / sqrtMu;
	const nextPosition = position.scale(f).add(velocity.scale(g));
	const nextRadius = nextPosition.magnitude;
	const fDot = sqrtMu / (nextRadius * radius) * chi * (z * s - 1);
	const gDot = 1 - chi * chi * c / nextRadius;
	return {
		position: nextPosition,
		velocity: position.scale(fDot).add(velocity.scale(gDot))
	};
}
function initialChi(alpha, radius, radialRate, mu, dt, sqrtMu) {
	if (alpha > 1e-8) return sqrtMu * dt * alpha;
	if (alpha < -1e-8) {
		const semi = 1 / alpha;
		const sqrtNegA = Math.sqrt(-semi);
		const denom = radialRate + Math.sign(dt) * Math.sqrt(-mu * semi) * (1 - radius * alpha);
		const numer = -2 * mu * alpha * dt;
		if (denom !== 0 && numer / denom > 0) return Math.sign(dt) * sqrtNegA * Math.log(numer / denom);
	}
	return sqrtMu * dt / radius;
}
/** Case B. Flip at 3 km, thrust off during the flip, then 60% vertical. */
var DEFAULT_TERMINAL_SEQUENCE = {
	triggerAltitudeM: TERMINAL_TRIGGER_ALTITUDE_M,
	triggerTimeS: null,
	flipDurationS: 8,
	flipThrottle: 0,
	landingThrottle: TERMINAL_LANDING_THROTTLE,
	manualCutoffS: null
};
/** Case C. Earlier altitude gate and full thrust. Same flip. */
var EARLY_TERMINAL_SEQUENCE = {
	triggerAltitudeM: TERMINAL_EARLY_ALTITUDE_M,
	triggerTimeS: null,
	flipDurationS: 8,
	flipThrottle: 0,
	landingThrottle: 1,
	manualCutoffS: null
};
function touchdownFlag(verticalMps, horizontalMps) {
	if (Math.abs(verticalMps) <= 2 && horizontalMps <= .5) return "nominal";
	return "RUD";
}
function pitchFromVerticalDeg(direction, position) {
	const radius = position.magnitude;
	if (!(radius > 0) || !(direction.magnitude > 0)) return 0;
	const up = position.scale(1 / radius);
	const cosine = Math.max(-1, Math.min(1, direction.normalized.dot(up)));
	return Math.acos(cosine) * 180 / Math.PI;
}
function inertialPitchFromYDeg(direction) {
	const cosine = Math.max(-1, Math.min(1, direction.normalized.y));
	return Math.acos(cosine) * 180 / Math.PI;
}
function localUp(position) {
	const radius = position.magnitude;
	if (!(radius > 0)) return Vector3d.up;
	return position.scale(1 / radius);
}
/** Unit slerp. Antiparallel vectors rotate through a perpendicular so the flip stays defined. */
function slerpUnit(from, to, u) {
	const a = from.normalized;
	const b = to.normalized;
	const clamped = Math.max(0, Math.min(1, u));
	if (!(a.magnitude > 0)) return b.magnitude > 0 ? b : Vector3d.up;
	if (!(b.magnitude > 0)) return a;
	const dot = Math.max(-1, Math.min(1, a.dot(b)));
	if (dot > .999999) return b;
	if (dot < -.999999) {
		const side = Math.abs(a.y) < .9 ? a.cross(Vector3d.up).normalized : a.cross(new Vector3d(1, 0, 0)).normalized;
		return clamped < .5 ? slerpUnit(a, side, clamped * 2) : slerpUnit(side, b, clamped * 2 - 1);
	}
	const omega = Math.acos(dot);
	const scale = Math.sin(omega);
	return a.scale(Math.sin((1 - clamped) * omega) / scale).add(b.scale(Math.sin(clamped * omega) / scale)).normalized;
}
/**
* Landing direction. fraction <= 0 returns `up` unchanged so Pass 6 stays the same vector.
* Otherwise normalize((1 - f) * up + f * opposition), with opposition against horizontal velocity.
*/
function landingThrustDirection(up, velocity, fraction) {
	if (!(fraction > 0)) return {
		direction: up,
		pitchFromVerticalDeg: 0
	};
	const f = fraction > 1 ? 1 : fraction;
	const horizontal = velocity.sub(up.scale(velocity.dot(up)));
	const speed = horizontal.magnitude;
	if (!(speed > 0)) return {
		direction: up,
		pitchFromVerticalDeg: 0
	};
	const opposition = horizontal.scale(-1 / speed);
	const direction = up.scale(1 - f).add(opposition.scale(f)).normalized;
	const cosine = Math.max(-1, Math.min(1, direction.dot(up)));
	return {
		direction,
		pitchFromVerticalDeg: Math.acos(cosine) * 180 / Math.PI
	};
}
/**
* Proportional landing fraction. clamp(k * vh / v_ref, 0, max_fraction).
* Not called on the FixedFraction path.
*/
function proportionalHorizontalFraction(config, position, velocity) {
	const gain = config.proportionalGain ?? 1;
	const reference = config.proportionalSpeedRefMps ?? 500;
	let cap = config.maxHorizontalFraction ?? .75;
	if (!(cap > 0)) cap = 0;
	const horizontal = horizontalSpeedMps(position, velocity);
	let fraction = reference > 0 ? gain * horizontal / reference : 0;
	if (!(fraction > 0)) fraction = 0;
	if (fraction > cap) fraction = cap;
	return fraction;
}
/**
* Point-mass terminal sequence. Thrust direction slews from the trigger's
* anti-velocity vector to local up, then stays on local up unless a horizontal
* landing fraction is set. No attitude state.
*/
var TerminalSequence = class {
	config;
	triggerAtS = null;
	retrograde = null;
	constructor(config) {
		this.config = config;
	}
	get triggerTimeS() {
		return this.triggerAtS;
	}
	command(timeS, position, velocity, propellantKg, altitudeM) {
		const up = localUp(position);
		if (this.triggerAtS === null) {
			const byTime = this.config.triggerTimeS !== null && timeS >= this.config.triggerTimeS;
			const byAltitude = this.config.triggerAltitudeM !== null && altitudeM > 0 && altitudeM <= this.config.triggerAltitudeM;
			if (byTime || byAltitude) {
				this.triggerAtS = timeS;
				this.retrograde = velocity.magnitude > 0 ? velocity.normalized.scale(-1) : up;
			}
		}
		if (this.triggerAtS === null || this.retrograde === null) return {
			phase: "Coast",
			throttle: 0,
			direction: up,
			pitchFromVerticalDeg: 0
		};
		const elapsed = timeS - this.triggerAtS;
		const cutoff = this.config.manualCutoffS !== null && timeS >= this.config.manualCutoffS;
		if (elapsed < this.config.flipDurationS && !cutoff) {
			const blend = this.config.flipDurationS > 0 ? elapsed / this.config.flipDurationS : 1;
			const direction = slerpUnit(this.retrograde, up, blend);
			return {
				phase: "Flip",
				throttle: this.config.flipThrottle,
				direction,
				pitchFromVerticalDeg: pitchFromVerticalDeg(direction, position)
			};
		}
		if (cutoff || propellantKg <= 0) return {
			phase: "Complete",
			throttle: 0,
			direction: up,
			pitchFromVerticalDeg: 0
		};
		if (this.config.guidanceMode === "Proportional") {
			const fraction = proportionalHorizontalFraction(this.config, position, velocity);
			const aim = landingThrustDirection(up, velocity, fraction > 1 ? 1 : fraction);
			return {
				phase: "LandingBurn",
				throttle: this.config.landingThrottle,
				direction: aim.direction,
				pitchFromVerticalDeg: aim.pitchFromVerticalDeg,
				horizontalFraction: fraction,
				guidanceMode: "Proportional"
			};
		}
		const fraction = this.config.horizontalFraction;
		if (!(typeof fraction === "number") || !(fraction > 0)) return {
			phase: "LandingBurn",
			throttle: this.config.landingThrottle,
			direction: up,
			pitchFromVerticalDeg: 0
		};
		const clamped = fraction > 1 ? 1 : fraction;
		const aim = landingThrustDirection(up, velocity, clamped);
		return {
			phase: "LandingBurn",
			throttle: this.config.landingThrottle,
			direction: aim.direction,
			pitchFromVerticalDeg: aim.pitchFromVerticalDeg,
			horizontalFraction: clamped
		};
	}
};
function assessImpact(state, peakSpeedMps) {
	const radius = state.position.magnitude;
	const vertical = radius > 0 ? state.velocity.dot(state.position) / radius : 0;
	const horizontal = horizontalSpeedMps(state.position, state.velocity);
	const speed = state.velocity.magnitude;
	return {
		verticalMps: vertical,
		horizontalMps: horizontal,
		speedMps: speed,
		kineticEnergyJ: .5 * state.totalMassKg * speed * speed,
		flag: touchdownFlag(vertical, horizontal),
		peakSpeedMps
	};
}
/**
* Linear segment between two RK4 states, solved so |r| = R.
* u is the fraction of the step. Position is then projected onto the sphere.
*/
function surfaceState(before, after, radiusM) {
	const dp = after.position.sub(before.position);
	const a = dp.sqrMagnitude;
	const b = 2 * before.position.dot(dp);
	const c = before.position.sqrMagnitude - radiusM * radiusM;
	let u = 1;
	if (a > 0) {
		const disc = b * b - 4 * a * c;
		if (disc >= 0) {
			const root = Math.sqrt(disc);
			const candidates = [(-b - root) / (2 * a), (-b + root) / (2 * a)].filter((value) => value >= -1e-9 && value <= 1 + 1e-9);
			if (candidates.length > 0) u = Math.max(0, Math.min(1, Math.min(...candidates)));
		}
	}
	const mix = (start, end) => start + (end - start) * u;
	const position = before.position.add(dp.scale(u));
	const onSurface = position.magnitude > 0 ? position.normalized.scale(radiusM) : new Vector3d(0, radiusM, 0);
	const propellant = Math.max(0, mix(before.propellantMassKg, after.propellantMassKg));
	return {
		u,
		state: {
			position: onSurface,
			velocity: new Vector3d(mix(before.velocity.x, after.velocity.x), mix(before.velocity.y, after.velocity.y), mix(before.velocity.z, after.velocity.z)),
			propellantMassKg: propellant,
			totalMassKg: before.totalMassKg + (after.totalMassKg - before.totalMassKg) * u,
			thrustIntegratedDeltaVMps: mix(before.thrustIntegratedDeltaVMps, after.thrustIntegratedDeltaVMps)
		}
	};
}
function formatTerminalSuffix(frame) {
	const phase = frame.sequencePhase ?? "Coast";
	const pitch = frame.thrustPitchFromVerticalDeg ?? 0;
	const radial = frame.radialMps ?? 0;
	let line = ` | phase=${phase} | pitchv=${pitch.toFixed(4)} deg | vrad=${radial.toFixed(4)}`;
	if (frame.impactFlag === "nominal" || frame.impactFlag === "RUD") line += ` | impact=${frame.impactFlag} | ke=${(frame.impactKineticEnergyJ ?? 0).toExponential(6)} J | vimp=${(frame.impactSpeedMps ?? 0).toFixed(4)} | vrad_imp=${(frame.impactVerticalMps ?? 0).toFixed(4)} | vhimp=${(frame.impactHorizontalMps ?? 0).toFixed(4)} | vpeak=${(frame.peakSpeedMps ?? 0).toFixed(4)}`;
	const fraction = frame.horizontalFraction ?? 0;
	const burnOrImpact = phase === "LandingBurn" || frame.impactFlag === "nominal" || frame.impactFlag === "RUD";
	if (frame.guidanceMode === "Proportional" && burnOrImpact) line += ` | guide=Proportional | hf=${fraction.toFixed(4)} | herr=${pitch.toFixed(4)} deg`;
	else if (fraction > 0 && burnOrImpact) line += ` | hf=${fraction.toFixed(4)} | herr=${pitch.toFixed(4)} deg`;
	return line;
}
function frameFromForce(timeS, velocity, position, propellantKg, force, thrustPitchDeg, engineState = 1, timeSinceCutoffS = 0, specificEnergyM2S2 = 0, propagationMode = "numerical", semiMajorAxisM = 0, eccentricity = 0, timeSinceElementsS = 0, body = "Earth", speedOfSoundMps = 340) {
	return {
		timeS,
		altitudeM: force.altitudeM,
		speedMps: velocity.magnitude,
		verticalMps: velocity.y,
		accelMps2: force.accelerationMagnitudeMps2,
		propellantKg,
		totalMassKg: force.massKg,
		thrustN: force.thrustN,
		dynamicPressurePa: force.dynamicPressurePa,
		densityKgM3: force.densityKgM3,
		dragN: force.dragN,
		gravityMps2: force.gravityMps2,
		horizontalMps: horizontalSpeedMps(position, velocity),
		flightPathDeg: flightPathAngleDeg(position, velocity),
		thrustPitchDeg,
		radiusM: position.magnitude,
		engineState,
		timeSinceCutoffS,
		specificEnergyM2S2,
		propagationMode,
		semiMajorAxisM,
		eccentricity,
		timeSinceElementsS,
		body,
		mach: speedOfSoundMps > 0 ? velocity.magnitude / speedOfSoundMps : 0
	};
}
function formatLogLine(frame) {
	return [
		`t=${frame.timeS.toFixed(3)} s`,
		`alt=${frame.altitudeM.toFixed(3)} m`,
		`v=${frame.speedMps.toFixed(4)} m/s`,
		`vy=${frame.verticalMps.toFixed(4)} m/s`,
		`a=${frame.accelMps2.toFixed(6)} m/s^2`,
		`mp=${frame.propellantKg.toFixed(3)} kg`,
		`m=${frame.totalMassKg.toFixed(3)} kg`,
		`T=${frame.thrustN.toFixed(1)} N`,
		`Q=${frame.dynamicPressurePa.toFixed(3)} Pa`,
		`rho=${frame.densityKgM3.toFixed(8)} kg/m^3`,
		`D=${frame.dragN.toFixed(3)} N`,
		`g=${frame.gravityMps2.toFixed(6)} m/s^2`,
		`vh=${frame.horizontalMps.toFixed(4)} m/s`,
		`gamma=${frame.flightPathDeg.toFixed(4)} deg`,
		`pitch=${frame.thrustPitchDeg.toFixed(4)} deg`,
		`r=${frame.radiusM.toFixed(3)} m`,
		`eng=${frame.engineState.toFixed(0)}`,
		`tco=${frame.timeSinceCutoffS.toFixed(3)} s`,
		`eps=${frame.specificEnergyM2S2.toExponential(6)} m^2/s^2`,
		`prop=${frame.propagationMode}`,
		`a=${Number.isFinite(frame.semiMajorAxisM) ? frame.semiMajorAxisM.toFixed(3) : "inf"} m`,
		`e=${frame.eccentricity.toFixed(8)}`,
		`tke=${frame.timeSinceElementsS.toFixed(3)} s`,
		`body=${frame.body}`,
		`M=${frame.mach.toFixed(4)}`
	].join(" | ");
}
var FRAME_STRIDE = 10;
var VACUUM_AGREEMENT_LIMIT = .001;
function sampleState(state, timeS, env, propulsion, throttle, thrustPitchDeg = 0, thrustDirection = Vector3d.up, timeSinceCutoffS = 0, body = env.name, speedOfSoundMps = env.speedOfSoundMps) {
	const force = evaluateForces(state.position, state.velocity, state.propellantMassKg, env, propulsion, throttle, thrustDirection);
	const mu = env.gravityEnabled ? env.muM3S2 : 0;
	return frameFromForce(timeS, state.velocity, state.position, state.propellantMassKg, force, thrustPitchDeg, throttle > 0 ? 1 : 0, timeSinceCutoffS, specificMechanicalEnergyM2S2(state.position, state.velocity, mu), "numerical", 0, 0, 0, body, speedOfSoundMps);
}
/**
* Headless Pass 1 verification.
* Sea-level Earth, position (0, R, 0), velocity 0, 100% +Y thrust for 90 s.
* Fixed step 0.02 s. Optional RK4 sub-stepping.
* Set disableGravityAndAtmosphere to compare integrated Δv with the rocket equation.
*/
function runVerticalBurn(disableGravityAndAtmosphere, substeps = 1) {
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const env = createEarthEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createSeaLevelState(env);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const steps = 4500;
	const logEvery = 250;
	const samples = [];
	const frames = [];
	const logLines = [];
	const header = disableGravityAndAtmosphere ? "ARES CORE vertical burn | mode=VACUUM | gravity=off | atmosphere=off | thrust=+Y | throttle=1 | dt=0.02 s" : "ARES CORE vertical burn | mode=EARTH | gravity=point-mass | atmosphere=exponential | thrust=+Y | throttle=1 | dt=0.02 s";
	logLines.push(header);
	for (let n = 0; n <= steps; n++) {
		const timeS = n / 50;
		if (n % logEvery === 0 || n % FRAME_STRIDE === 0) {
			const frame = sampleState(state, timeS, env, propulsion, 1);
			if (n % FRAME_STRIDE === 0) frames.push(frame);
			if (n % logEvery === 0) {
				samples.push(frame);
				logLines.push(formatLogLine(frame));
			}
		}
		if (n === steps) break;
		state = stepRk4(state, 1 / 50, substeps, env, propulsion, 1);
	}
	const finalMassKg = state.totalMassKg;
	const ideal = idealRocketDeltaVMps(propulsion, initialMassKg, finalMassKg);
	const achieved = state.velocity.sub(initialVelocity).magnitude;
	const thrustDv = state.thrustIntegratedDeltaVMps;
	const difference = ideal - achieved;
	const relativeError = ideal > 0 ? Math.abs(achieved - ideal) / ideal : 0;
	const vacuumCheckApplies = disableGravityAndAtmosphere;
	const vacuumCheckPassed = !vacuumCheckApplies || relativeError < VACUUM_AGREEMENT_LIMIT;
	logLines.push(`ideal_dv_m_s=${ideal.toFixed(6)}`);
	logLines.push(`achieved_dv_m_s=${achieved.toFixed(6)}`);
	logLines.push(`thrust_integrated_dv_m_s=${thrustDv.toFixed(6)}`);
	logLines.push(`difference_ideal_minus_achieved_m_s=${difference.toFixed(6)}`);
	logLines.push(`relative_error=${(relativeError * 100).toFixed(8)} %`);
	logLines.push(vacuumCheckApplies ? `verdict=${vacuumCheckPassed ? "PASS" : "FAIL"} vacuum agreement limit=0.10000000 %` : "verdict=GRAVITY_AND_DRAG_LOSS vacuum agreement not applicable");
	return {
		disableGravityAndAtmosphere,
		substeps,
		samples,
		frames,
		logLines,
		logText: logLines.join("\n"),
		initialMassKg,
		finalMassKg,
		initialVelocity,
		finalPosition: state.position,
		finalVelocity: state.velocity,
		idealDeltaVMps: ideal,
		achievedDeltaVMps: achieved,
		thrustIntegratedDeltaVMps: thrustDv,
		differenceMps: difference,
		relativeError,
		vacuumCheckApplies,
		vacuumCheckPassed,
		pitchProgram: null,
		cutoff: null,
		endTimeS: 90
	};
}
/**
* Same 90 s sea-level burn as Pass 1, with an open-loop thrust direction.
* A program that never leaves +Y delegates to runVerticalBurn, so those numbers stay identical.
*/
function runPitchedBurn(disableGravityAndAtmosphere, substeps = 1, program) {
	if (pitchAngleDeg(90, program) === 0) return runVerticalBurn(disableGravityAndAtmosphere, substeps);
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const env = createEarthEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createSeaLevelState(env);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const steps = 4500;
	const logEvery = 250;
	const samples = [];
	const frames = [];
	const logLines = [];
	const mode = disableGravityAndAtmosphere ? "VACUUM" : "EARTH";
	const pitchText = program.holdPitchDeg === null ? `pitch_rate=${program.pitchRateDegPerS} deg/s` : `hold_pitch=${program.holdPitchDeg} deg`;
	logLines.push(`ARES CORE pitch program | mode=${mode} | t_vertical=${program.tVerticalS} s | ${pitchText} | plane=XY | throttle=1 | dt=0.02 s`);
	for (let n = 0; n <= steps; n++) {
		const timeS = n / 50;
		const pitchDeg = pitchAngleDeg(timeS, program);
		const direction = thrustDirectionAt(timeS, program);
		if (n % logEvery === 0 || n % FRAME_STRIDE === 0) {
			const frame = sampleState(state, timeS, env, propulsion, 1, pitchDeg, direction);
			if (n % FRAME_STRIDE === 0) frames.push(frame);
			if (n % logEvery === 0) {
				samples.push(frame);
				logLines.push(formatLogLine(frame));
			}
		}
		if (n === steps) break;
		state = stepRk4(state, 1 / 50, substeps, env, propulsion, 1, direction);
	}
	const finalMassKg = state.totalMassKg;
	const ideal = idealRocketDeltaVMps(propulsion, initialMassKg, finalMassKg);
	const achieved = state.velocity.sub(initialVelocity).magnitude;
	const thrustDv = state.thrustIntegratedDeltaVMps;
	const difference = ideal - achieved;
	const relativeError = ideal > 0 ? Math.abs(achieved - ideal) / ideal : 0;
	logLines.push(`ideal_dv_m_s=${ideal.toFixed(6)}`);
	logLines.push(`achieved_dv_m_s=${achieved.toFixed(6)}`);
	logLines.push(`thrust_integrated_dv_m_s=${thrustDv.toFixed(6)}`);
	logLines.push(`difference_ideal_minus_achieved_m_s=${difference.toFixed(6)}`);
	logLines.push(`relative_error=${(relativeError * 100).toFixed(8)} %`);
	logLines.push("verdict=OPEN_LOOP_PITCH");
	return {
		disableGravityAndAtmosphere,
		substeps,
		samples,
		frames,
		logLines,
		logText: logLines.join("\n"),
		initialMassKg,
		finalMassKg,
		initialVelocity,
		finalPosition: state.position,
		finalVelocity: state.velocity,
		idealDeltaVMps: ideal,
		achievedDeltaVMps: achieved,
		thrustIntegratedDeltaVMps: thrustDv,
		differenceMps: difference,
		relativeError,
		vacuumCheckApplies: false,
		vacuumCheckPassed: true,
		pitchProgram: program,
		cutoff: null,
		endTimeS: 90
	};
}
function markCutoff(mark, timeS) {
	if (mark.timeS === null || timeS < mark.timeS) mark.timeS = timeS;
}
/**
* One major step. Throttle is 1 until cutoff, then 0.
* A cutoff that lands inside the step splits it. The RK4 step itself is unchanged.
* With no cutoff this is a single stepRk4 of the full dt.
*/
function stepCommanded(state, timeS, dt, substeps, env, propulsion, cutoff, direction, mark) {
	let cursor = timeS;
	let left = dt;
	let current = state;
	for (let guard = 0; guard < 4 && left > 1e-12; guard++) {
		if (!(commandThrottle(cursor, current.propellantMassKg, cutoff) > 0)) {
			markCutoff(mark, cursor);
			return stepRk4(current, left, substeps, env, propulsion, 0, direction);
		}
		let segment = left;
		let snapTo = null;
		if (cutoff.tCutoffS !== null && cursor < cutoff.tCutoffS && cursor + segment > cutoff.tCutoffS) segment = cutoff.tCutoffS - cursor;
		if (cutoff.propellantRemainingKg !== null) {
			const threshold = cutoff.propellantRemainingKg;
			const burnable = current.propellantMassKg - threshold;
			const mdot = massFlowKgS(propulsion, 1, current.propellantMassKg);
			if (!(burnable > 0) || !(mdot > 0)) {
				markCutoff(mark, cursor);
				return stepRk4(current, left, substeps, env, propulsion, 0, direction);
			}
			const dtFuel = burnable / mdot;
			if (dtFuel < segment) {
				segment = dtFuel;
				snapTo = threshold;
			}
		}
		if (!(segment > 0)) break;
		if (segment >= left - 1e-15 && snapTo === null) return stepRk4(current, left, substeps, env, propulsion, 1, direction);
		current = stepRk4(current, segment, substeps, env, propulsion, 1, direction);
		cursor += segment;
		left -= segment;
		if (snapTo !== null) {
			current = {
				position: current.position,
				velocity: current.velocity,
				propellantMassKg: snapTo,
				totalMassKg: DRY_MASS_KG + Math.max(snapTo, 0),
				thrustIntegratedDeltaVMps: current.thrustIntegratedDeltaVMps
			};
			markCutoff(mark, cursor);
			if (left > 1e-12) return stepRk4(current, left, substeps, env, propulsion, 0, direction);
			return current;
		}
	}
	return current;
}
/**
* Pass 3. Same sea-level burn as Pass 1 / Pass 2, with optional cutoff and a longer coast.
* Cutoff that cannot engage before endTime, on a 90 s run, delegates to the verified function.
*/
function runCoastBurn(disableGravityAndAtmosphere, substeps, program, cutoff, endTimeS) {
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const steps = Math.round(endTimeS * 50);
	if (!(steps > 0) || Math.abs(endTimeS * 50 - steps) > 1e-6) throw new Error("end time must land on the 50 Hz step grid");
	if (cutoff.propellantRemainingKg === null && (cutoff.tCutoffS === null || cutoff.tCutoffS > endTimeS) && endTimeS === 90) {
		if (pitchAngleDeg(90, program) === 0) return runVerticalBurn(disableGravityAndAtmosphere, substeps);
		return runPitchedBurn(disableGravityAndAtmosphere, substeps, program);
	}
	const env = createEarthEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createSeaLevelState(env);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const mark = { timeS: null };
	const logEvery = 250;
	const samples = [];
	const frames = [];
	const logLines = [];
	const mode = disableGravityAndAtmosphere ? "VACUUM" : "EARTH";
	const pitchText = pitchAngleDeg(endTimeS, program) === 0 ? "pitch=vertical" : program.holdPitchDeg === null ? `pitch_rate=${program.pitchRateDegPerS} deg/s after ${program.tVerticalS} s` : `hold_pitch=${program.holdPitchDeg} deg after ${program.tVerticalS} s`;
	const cutoffText = cutoff.tCutoffS === null ? "t_cutoff=never" : `t_cutoff=${cutoff.tCutoffS} s`;
	const propText = cutoff.propellantRemainingKg === null ? "mp_cutoff=none" : `mp_cutoff=${cutoff.propellantRemainingKg} kg`;
	logLines.push(`ARES CORE cutoff coast | mode=${mode} | ${cutoffText} | ${propText} | end=${endTimeS} s | ${pitchText} | dt=0.02 s`);
	for (let n = 0; n <= steps; n++) {
		const timeS = n / 50;
		const pitchDeg = pitchAngleDeg(timeS, program);
		const direction = thrustDirectionAt(timeS, program);
		const throttle = commandThrottle(timeS, state.propellantMassKg, cutoff);
		if (throttle === 0) markCutoff(mark, timeS);
		const since = mark.timeS === null || !(timeS > mark.timeS) ? 0 : timeS - mark.timeS;
		if (n % logEvery === 0 || n % FRAME_STRIDE === 0) {
			const frame = sampleState(state, timeS, env, propulsion, throttle, pitchDeg, direction, since);
			if (n % FRAME_STRIDE === 0) frames.push(frame);
			if (n % logEvery === 0) {
				samples.push(frame);
				logLines.push(formatLogLine(frame));
			}
		}
		if (n === steps) break;
		state = stepCommanded(state, timeS, 1 / 50, substeps, env, propulsion, cutoff, direction, mark);
	}
	const finalMassKg = state.totalMassKg;
	const ideal = idealRocketDeltaVMps(propulsion, initialMassKg, finalMassKg);
	const achieved = state.velocity.sub(initialVelocity).magnitude;
	const thrustDv = state.thrustIntegratedDeltaVMps;
	const difference = ideal - achieved;
	const relativeError = ideal > 0 ? Math.abs(achieved - ideal) / ideal : 0;
	const engaged = mark.timeS !== null;
	logLines.push(`ideal_dv_m_s=${ideal.toFixed(6)}`);
	logLines.push(`achieved_dv_m_s=${achieved.toFixed(6)}`);
	logLines.push(`thrust_integrated_dv_m_s=${thrustDv.toFixed(6)}`);
	logLines.push(`difference_ideal_minus_achieved_m_s=${difference.toFixed(6)}`);
	logLines.push(`relative_error=${(relativeError * 100).toFixed(8)} %`);
	logLines.push(engaged ? "verdict=CUTOFF_AND_COAST" : "verdict=CONTINUOUS_THRUST");
	return {
		disableGravityAndAtmosphere,
		substeps,
		samples,
		frames,
		logLines,
		logText: logLines.join("\n"),
		initialMassKg,
		finalMassKg,
		initialVelocity,
		finalPosition: state.position,
		finalVelocity: state.velocity,
		idealDeltaVMps: ideal,
		achievedDeltaVMps: achieved,
		thrustIntegratedDeltaVMps: thrustDv,
		differenceMps: difference,
		relativeError,
		vacuumCheckApplies: false,
		vacuumCheckPassed: true,
		pitchProgram: pitchAngleDeg(endTimeS, program) === 0 ? null : program,
		cutoff: engaged ? cutoff : null,
		endTimeS
	};
}
function analyticForce(position, massKg, mu, equatorialRadiusM) {
	const radius = position.magnitude;
	const gravity = mu > 0 && radius > 0 ? mu / (radius * radius) : 0;
	const gravityAccel = gravity > 0 ? position.scale(-gravity / radius) : Vector3d.zero;
	return {
		altitudeM: radius - equatorialRadiusM,
		massKg,
		acceleration: gravityAccel,
		accelerationMagnitudeMps2: gravity,
		thrustN: 0,
		thrustAccelMps2: 0,
		dragN: 0,
		dragAccel: Vector3d.zero,
		gravityMps2: gravity,
		gravityAccel,
		densityKgM3: 0,
		dynamicPressurePa: 0,
		massFlowKgS: 0
	};
}
/**
* Pass 4. Powered flight and the cutoff instant stay on the Pass 3 RK4 path.
* After thrust is zero, position and velocity come from a universal-variable Kepler step.
* Drag is not applied on that arc. Gravity off degenerates to a straight line.
* A cutoff that never engages delegates to {@link runCoastBurn}.
*/
function runKeplerCoast(disableGravityAndAtmosphere, substeps, program, cutoff, endTimeS) {
	if (cutoff.propellantRemainingKg === null && (cutoff.tCutoffS === null || cutoff.tCutoffS > endTimeS)) return runCoastBurn(disableGravityAndAtmosphere, substeps, program, cutoff, endTimeS);
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const steps = Math.round(endTimeS * 50);
	if (!(steps > 0) || Math.abs(endTimeS * 50 - steps) > 1e-6) throw new Error("end time must land on the 50 Hz step grid");
	const env = createEarthEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createSeaLevelState(env);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const mark = { timeS: null };
	let capture = null;
	const logEvery = 250;
	const samples = [];
	const frames = [];
	const logLines = [];
	const mu = env.gravityEnabled ? env.muM3S2 : 0;
	const mode = disableGravityAndAtmosphere ? "VACUUM" : "EARTH";
	const pitchText = pitchAngleDeg(endTimeS, program) === 0 ? "pitch=vertical" : program.holdPitchDeg === null ? `pitch_rate=${program.pitchRateDegPerS} deg/s after ${program.tVerticalS} s` : `hold_pitch=${program.holdPitchDeg} deg after ${program.tVerticalS} s`;
	const cutoffText = cutoff.tCutoffS === null ? "t_cutoff=never" : `t_cutoff=${cutoff.tCutoffS} s`;
	logLines.push(`ARES CORE analytic kepler | mode=${mode} | ${cutoffText} | end=${endTimeS} s | ${pitchText} | drag=off | dt=0.02 s`);
	for (let n = 0; n <= steps; n++) {
		const timeS = n / 50;
		if (capture && timeS > capture.timeS) {
			const propagated = propagateKepler(capture.position, capture.velocity, capture.muM3S2, timeS - capture.timeS);
			state = {
				position: propagated.position,
				velocity: propagated.velocity,
				propellantMassKg: capture.propellantKg,
				totalMassKg: capture.totalMassKg,
				thrustIntegratedDeltaVMps: capture.thrustIntegratedDeltaVMps
			};
		}
		const pitchDeg = pitchAngleDeg(timeS, program);
		const direction = thrustDirectionAt(timeS, program);
		const throttle = commandThrottle(timeS, state.propellantMassKg, cutoff);
		if (capture === null && throttle === 0) {
			const elements = keplerElements(state.position, state.velocity, mu);
			capture = {
				timeS,
				position: state.position,
				velocity: state.velocity,
				muM3S2: mu,
				propellantKg: state.propellantMassKg,
				totalMassKg: state.totalMassKg,
				thrustIntegratedDeltaVMps: state.thrustIntegratedDeltaVMps,
				elements
			};
			markCutoff(mark, timeS);
		} else if (throttle === 0) markCutoff(mark, timeS);
		const since = mark.timeS === null || !(timeS > mark.timeS) ? 0 : timeS - mark.timeS;
		const onAnalyticArc = capture !== null && timeS > capture.timeS;
		if (n % logEvery === 0 || n % FRAME_STRIDE === 0) {
			let frame;
			if (onAnalyticArc && capture) {
				const force = analyticForce(state.position, capture.totalMassKg, mu, env.equatorialRadiusM);
				frame = frameFromForce(timeS, state.velocity, state.position, capture.propellantKg, force, pitchDeg, 0, since, specificMechanicalEnergyM2S2(state.position, state.velocity, mu), "analytic", capture.elements.semiMajorAxisM, capture.elements.eccentricity, timeS - capture.timeS);
			} else {
				frame = sampleState(state, timeS, env, propulsion, throttle, pitchDeg, direction, since);
				if (capture && timeS === capture.timeS) frame = {
					...frame,
					semiMajorAxisM: capture.elements.semiMajorAxisM,
					eccentricity: capture.elements.eccentricity,
					timeSinceElementsS: 0
				};
			}
			if (n % FRAME_STRIDE === 0) frames.push(frame);
			if (n % logEvery === 0) {
				samples.push(frame);
				logLines.push(formatLogLine(frame));
			}
		}
		if (n === steps) break;
		if (capture) continue;
		state = stepCommanded(state, timeS, 1 / 50, substeps, env, propulsion, cutoff, direction, mark);
	}
	const finalMassKg = state.totalMassKg;
	const ideal = idealRocketDeltaVMps(propulsion, initialMassKg, finalMassKg);
	const achieved = state.velocity.sub(initialVelocity).magnitude;
	const thrustDv = state.thrustIntegratedDeltaVMps;
	const difference = ideal - achieved;
	const relativeError = ideal > 0 ? Math.abs(achieved - ideal) / ideal : 0;
	logLines.push(`ideal_dv_m_s=${ideal.toFixed(6)}`);
	logLines.push(`achieved_dv_m_s=${achieved.toFixed(6)}`);
	logLines.push(`thrust_integrated_dv_m_s=${thrustDv.toFixed(6)}`);
	logLines.push(`difference_ideal_minus_achieved_m_s=${difference.toFixed(6)}`);
	logLines.push(`relative_error=${(relativeError * 100).toFixed(8)} %`);
	logLines.push(capture ? "verdict=ANALYTIC_KEPLER" : "verdict=CONTINUOUS_THRUST");
	return {
		disableGravityAndAtmosphere,
		substeps,
		samples,
		frames,
		logLines,
		logText: logLines.join("\n"),
		initialMassKg,
		finalMassKg,
		initialVelocity,
		finalPosition: state.position,
		finalVelocity: state.velocity,
		idealDeltaVMps: ideal,
		achievedDeltaVMps: achieved,
		thrustIntegratedDeltaVMps: thrustDv,
		differenceMps: difference,
		relativeError,
		vacuumCheckApplies: false,
		vacuumCheckPassed: true,
		pitchProgram: pitchAngleDeg(endTimeS, program) === 0 ? null : program,
		cutoff: capture ? cutoff : null,
		endTimeS,
		analyticKepler: capture !== null,
		keplerCapture: capture
	};
}
function closeReport(state, initialVelocity, initialMassKg, propulsion, disableGravityAndAtmosphere, substeps, samples, frames, logLines, endTimeS, verdict, extra = {}) {
	const finalMassKg = state.totalMassKg;
	const ideal = idealRocketDeltaVMps(propulsion, initialMassKg, finalMassKg);
	const achieved = state.velocity.sub(initialVelocity).magnitude;
	const thrustDv = state.thrustIntegratedDeltaVMps;
	const difference = ideal - achieved;
	const relativeError = ideal > 0 ? Math.abs(achieved - ideal) / ideal : 0;
	logLines.push(`ideal_dv_m_s=${ideal.toFixed(6)}`);
	logLines.push(`achieved_dv_m_s=${achieved.toFixed(6)}`);
	logLines.push(`thrust_integrated_dv_m_s=${thrustDv.toFixed(6)}`);
	logLines.push(`difference_ideal_minus_achieved_m_s=${difference.toFixed(6)}`);
	logLines.push(`relative_error=${(relativeError * 100).toFixed(8)} %`);
	logLines.push(verdict);
	return {
		disableGravityAndAtmosphere,
		substeps,
		samples,
		frames,
		logLines,
		logText: logLines.join("\n"),
		initialMassKg,
		finalMassKg,
		initialVelocity,
		finalPosition: state.position,
		finalVelocity: state.velocity,
		idealDeltaVMps: ideal,
		achievedDeltaVMps: achieved,
		thrustIntegratedDeltaVMps: thrustDv,
		differenceMps: difference,
		relativeError,
		vacuumCheckApplies: false,
		vacuumCheckPassed: true,
		pitchProgram: null,
		cutoff: null,
		endTimeS,
		...extra
	};
}
/**
* Pass 5. Pure vertical thrust from the Mars surface.
* Same RK4 step and vehicle as Earth. Does not run when Earth is selected.
*/
function runMarsVerticalBurn(disableGravityAndAtmosphere, substeps = 1, durationS = 60) {
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const steps = Math.round(durationS * 50);
	if (!(steps > 0) || Math.abs(durationS * 50 - steps) > 1e-6) throw new Error("end time must land on the 50 Hz step grid");
	const env = createMarsEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createSeaLevelState(env);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const logEvery = 250;
	const samples = [];
	const frames = [];
	const logLines = [];
	const mode = disableGravityAndAtmosphere ? "VACUUM" : "MARS";
	logLines.push(`ARES CORE mars vertical burn | mode=${mode} | body=Mars | thrust=+Y | throttle=1 | end=${durationS} s | dt=0.02 s`);
	for (let n = 0; n <= steps; n++) {
		const timeS = n / 50;
		if (n % logEvery === 0 || n % FRAME_STRIDE === 0) {
			const frame = sampleState(state, timeS, env, propulsion, 1);
			if (n % FRAME_STRIDE === 0) frames.push(frame);
			if (n % logEvery === 0) {
				samples.push(frame);
				logLines.push(formatLogLine(frame));
			}
		}
		if (n === steps) break;
		state = stepRk4(state, 1 / 50, substeps, env, propulsion, 1);
	}
	return closeReport(state, initialVelocity, initialMassKg, propulsion, disableGravityAndAtmosphere, substeps, samples, frames, logLines, durationS, "verdict=MARS_SURFACE_BURN");
}
/**
* Pass 5 entry interface. Engines stay off.
* Numerical coast uses RK4 with the active atmosphere. Analytic Kepler ignores drag.
*/
function runMarsEntry(disableGravityAndAtmosphere, substeps = 1, analytic = false, endTimeS = 300, entry = MARS_ENTRY_INTERFACE) {
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const steps = Math.round(endTimeS * 50);
	if (!(steps > 0) || Math.abs(endTimeS * 50 - steps) > 1e-6) throw new Error("end time must land on the 50 Hz step grid");
	const env = createMarsEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createEntryState(env, entry);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const mu = env.gravityEnabled ? env.muM3S2 : 0;
	const logEvery = 250;
	const samples = [];
	const frames = [];
	const logLines = [];
	const mode = disableGravityAndAtmosphere ? "VACUUM" : "MARS";
	logLines.push(`ARES CORE mars entry | mode=${mode} | body=Mars | h0=${entry.altitudeM} m | v0=${entry.speedMps} m/s | gamma0=${entry.flightPathDeg} deg | mp=${entry.propellantKg} kg | coast=${analytic ? "analytic" : "numerical"} | end=${endTimeS} s | dt=0.02 s`);
	let capture = null;
	if (analytic) capture = {
		timeS: 0,
		position: state.position,
		velocity: state.velocity,
		muM3S2: mu,
		propellantKg: state.propellantMassKg,
		totalMassKg: state.totalMassKg,
		thrustIntegratedDeltaVMps: state.thrustIntegratedDeltaVMps,
		elements: keplerElements(state.position, state.velocity, mu)
	};
	for (let n = 0; n <= steps; n++) {
		const timeS = n / 50;
		if (capture && timeS > capture.timeS) {
			const propagated = propagateKepler(capture.position, capture.velocity, capture.muM3S2, timeS - capture.timeS);
			state = {
				position: propagated.position,
				velocity: propagated.velocity,
				propellantMassKg: capture.propellantKg,
				totalMassKg: capture.totalMassKg,
				thrustIntegratedDeltaVMps: capture.thrustIntegratedDeltaVMps
			};
		}
		const onAnalyticArc = capture !== null && timeS > capture.timeS;
		if (n % logEvery === 0 || n % FRAME_STRIDE === 0) {
			let frame;
			if (onAnalyticArc && capture) {
				const force = analyticForce(state.position, capture.totalMassKg, mu, env.equatorialRadiusM);
				frame = frameFromForce(timeS, state.velocity, state.position, capture.propellantKg, force, 0, 0, timeS, specificMechanicalEnergyM2S2(state.position, state.velocity, mu), "analytic", capture.elements.semiMajorAxisM, capture.elements.eccentricity, timeS - capture.timeS, env.name, env.speedOfSoundMps);
			} else {
				frame = sampleState(state, timeS, env, propulsion, 0, 0, Vector3d.up, timeS);
				if (capture && timeS === capture.timeS) frame = {
					...frame,
					semiMajorAxisM: capture.elements.semiMajorAxisM,
					eccentricity: capture.elements.eccentricity,
					timeSinceElementsS: 0
				};
			}
			if (n % FRAME_STRIDE === 0) frames.push(frame);
			if (n % logEvery === 0) {
				samples.push(frame);
				logLines.push(formatLogLine(frame));
			}
		}
		if (n === steps) break;
		if (capture) continue;
		state = stepRk4(state, 1 / 50, substeps, env, propulsion, 0);
	}
	return closeReport(state, initialVelocity, initialMassKg, propulsion, disableGravityAndAtmosphere, substeps, samples, frames, logLines, endTimeS, analytic ? "verdict=MARS_ENTRY_ANALYTIC" : "verdict=MARS_ENTRY_NUMERICAL", {
		analyticKepler: analytic,
		keplerCapture: capture
	});
}
var TERMINAL_FRAME_STRIDE = 50;
/**
* Pass 6. Mars entry with an open-loop flip and landing burn.
* Not called by any Pass 1–5 path. Engines stay off until the trigger.
*/
function runMarsTerminalLanding(disableGravityAndAtmosphere, substeps = 1, config = DEFAULT_TERMINAL_SEQUENCE, entry = MARS_ENTRY_INTERFACE) {
	if (!Number.isInteger(substeps) || substeps < 1) throw new Error("substeps must be a positive integer");
	const dt = 1 / 50;
	const maxSteps = Math.round(TERMINAL_MAX_TIME_S * 50);
	const logEvery = 250;
	const env = createMarsEnvironment({
		gravityEnabled: !disableGravityAndAtmosphere,
		atmosphereEnabled: !disableGravityAndAtmosphere,
		includeJ2: false
	});
	const propulsion = createDefaultPropulsion();
	let state = createEntryState(env, entry);
	const initialVelocity = state.velocity;
	const initialMassKg = state.totalMassKg;
	const sequence = new TerminalSequence(config);
	const samples = [];
	const frames = [];
	const logLines = [];
	const mode = disableGravityAndAtmosphere ? "VACUUM" : "MARS";
	const triggerLabel = config.triggerTimeS !== null ? `t:${config.triggerTimeS}` : `h:${config.triggerAltitudeM ?? "none"}`;
	const proportional = config.guidanceMode === "Proportional";
	const rawFraction = config.horizontalFraction;
	const hfSuffix = !proportional && typeof rawFraction === "number" && rawFraction > 0 ? ` | hf=${(rawFraction > 1 ? 1 : rawFraction).toFixed(4)}` : "";
	const guideSuffix = proportional ? ` | guide=Proportional | k=${(config.proportionalGain ?? 1).toFixed(4)} | vref=${(config.proportionalSpeedRefMps ?? 500).toFixed(3)} | hf_max=${(config.maxHorizontalFraction ?? .75).toFixed(4)}` : "";
	logLines.push(`ARES CORE mars terminal | mode=${mode} | body=Mars | trigger=${triggerLabel} | flip=${config.flipDurationS} s | flip_throttle=${config.flipThrottle} | landing_throttle=${config.landingThrottle} | dt=0.02 s${hfSuffix}${guideSuffix}`);
	let loggedPhase = null;
	let peak = state.velocity.magnitude;
	let impact = null;
	let endTimeS = 0;
	const pushFrame = (frame, sample) => {
		frames.push(frame);
		if (!sample) return;
		samples.push(frame);
		logLines.push(formatLogLine(frame) + formatTerminalSuffix(frame));
	};
	for (let n = 0; n <= maxSteps; n++) {
		const timeS = n / 50;
		const height = altitudeM(env, state.position);
		const speed = state.velocity.magnitude;
		if (speed > peak) peak = speed;
		const command = sequence.command(timeS, state.position, state.velocity, state.propellantMassKg, height);
		const phaseChanged = command.phase !== loggedPhase;
		const onLog = n % logEvery === 0;
		if (n % TERMINAL_FRAME_STRIDE === 0 || onLog || phaseChanged) {
			pushFrame(decorateTerminal(state, timeS, env, propulsion, command, null, peak), onLog || phaseChanged);
			loggedPhase = command.phase;
		}
		if (height <= 0) {
			impact = assessImpact(state, Math.max(peak, state.velocity.magnitude));
			const landed = {
				...state,
				position: state.position.magnitude > 0 ? state.position.normalized.scale(env.equatorialRadiusM) : new Vector3d(0, env.equatorialRadiusM, 0)
			};
			pushFrame(decorateTerminal(landed, timeS, env, propulsion, impactCommand(config, landed, command), impact, impact.peakSpeedMps), true);
			endTimeS = timeS;
			state = landed;
			break;
		}
		if (n === maxSteps) {
			endTimeS = timeS;
			break;
		}
		const before = cloneState(state);
		state = stepRk4(state, dt, substeps, env, propulsion, command.throttle, command.direction);
		if (altitudeM(env, state.position) <= 0 && height > 0) {
			const hit = surfaceState(before, state, env.equatorialRadiusM);
			state = hit.state;
			endTimeS = timeS + hit.u * dt;
			const hitSpeed = state.velocity.magnitude;
			if (hitSpeed > peak) peak = hitSpeed;
			impact = assessImpact(state, peak);
			const hitCommand = sequence.command(endTimeS, state.position, state.velocity, state.propellantMassKg, 0);
			pushFrame(decorateTerminal(state, endTimeS, env, propulsion, impactCommand(config, state, hitCommand), impact, peak), true);
			break;
		}
	}
	return closeReport(state, initialVelocity, initialMassKg, propulsion, disableGravityAndAtmosphere, substeps, samples, frames, logLines, endTimeS, impact ? impact.flag === "nominal" ? "verdict=TERMINAL_NOMINAL" : "verdict=TERMINAL_RUD" : "verdict=TERMINAL_NO_IMPACT", { terminal: {
		config,
		triggerTimeS: sequence.triggerTimeS,
		impact,
		peakSpeedMps: peak
	} });
}
function impactCommand(config, state, command) {
	const settled = {
		...command,
		phase: "Complete",
		throttle: 0
	};
	if (config.guidanceMode === "Proportional") {
		const fraction = proportionalHorizontalFraction(config, state.position, state.velocity);
		const aim = landingThrustDirection(state.position.magnitude > 0 ? state.position.normalized : Vector3d.up, state.velocity, fraction > 1 ? 1 : fraction);
		return {
			...settled,
			direction: aim.direction,
			pitchFromVerticalDeg: aim.pitchFromVerticalDeg,
			horizontalFraction: fraction,
			guidanceMode: "Proportional"
		};
	}
	const fraction = config.horizontalFraction;
	if (!(typeof fraction === "number") || !(fraction > 0)) return settled;
	const clamped = fraction > 1 ? 1 : fraction;
	const aim = landingThrustDirection(state.position.magnitude > 0 ? state.position.normalized : Vector3d.up, state.velocity, clamped);
	return {
		...settled,
		direction: aim.direction,
		pitchFromVerticalDeg: aim.pitchFromVerticalDeg,
		horizontalFraction: clamped
	};
}
function decorateTerminal(state, timeS, env, propulsion, command, impact, peakSpeedMps) {
	const frame = sampleState(state, timeS, env, propulsion, command.throttle, inertialPitchFromYDeg(command.direction), command.direction, 0);
	const radial = state.position.magnitude > 0 ? state.velocity.dot(state.position.normalized) : 0;
	return {
		...frame,
		altitudeM: impact ? 0 : frame.altitudeM,
		sequencePhase: impact ? "Complete" : command.phase,
		thrustPitchFromVerticalDeg: command.pitchFromVerticalDeg,
		radialMps: radial,
		impactFlag: impact?.flag ?? "",
		impactKineticEnergyJ: impact?.kineticEnergyJ,
		impactSpeedMps: impact?.speedMps,
		impactVerticalMps: impact?.verticalMps,
		impactHorizontalMps: impact?.horizontalMps,
		peakSpeedMps,
		...command.guidanceMode === "Proportional" ? {
			guidanceMode: "Proportional",
			horizontalFraction: command.horizontalFraction ?? 0
		} : command.horizontalFraction !== void 0 && command.horizontalFraction > 0 ? { horizontalFraction: command.horizontalFraction } : {}
	};
}
var SOURCE_FILES = [
	"Assets/Scripts/Math/DoublePrecisionMath.cs",
	"Assets/Scripts/PhysicsCore/VehicleState.cs",
	"Assets/Scripts/PhysicsCore/PlanetaryEnvironment.cs",
	"Assets/Scripts/PhysicsCore/PropulsionModel.cs",
	"Assets/Scripts/PhysicsCore/PitchProgram.cs",
	"Assets/Scripts/PhysicsCore/CutoffCommand.cs",
	"Assets/Scripts/PhysicsCore/IntegratorRK4.cs",
	"Assets/Scripts/PhysicsCore/KeplerPropagator.cs",
	"Assets/Scripts/PhysicsCore/TerminalSequence.cs",
	"Assets/Scripts/PhysicsCore/SimulationHarness.cs",
	"Assets/Scripts/PhysicsCore/AresVerticalBurnDriver.cs"
];
function formatFixed(value, digits) {
	if (!Number.isFinite(value)) return "—";
	const negative = value < 0;
	const [whole, frac] = Math.abs(value).toFixed(digits).split(".");
	const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	return `${negative ? "-" : ""}${grouped}${frac !== void 0 ? `.${frac}` : ""}`;
}
function formatTick(seconds) {
	const whole = Math.round(seconds);
	const minutes = Math.floor(whole / 60);
	const rem = whole % 60;
	return `${String(minutes).padStart(2, "0")}:${String(rem).padStart(2, "0")}`;
}
function formatMet(seconds) {
	const centi = Math.round(seconds * 100);
	const whole = Math.floor(centi / 100);
	const frac = centi % 100;
	const minutes = Math.floor(whole / 60);
	const rem = whole % 60;
	return `${String(minutes).padStart(2, "0")}:${String(rem).padStart(2, "0")}.${String(frac).padStart(2, "0")}`;
}
function formatDensity(value) {
	if (!Number.isFinite(value)) return "—";
	if (value !== 0 && Math.abs(value) < 1e-4) return value.toExponential(3);
	return formatFixed(value, 6);
}
function formatTiny(value, digits, unit) {
	if (!Number.isFinite(value)) return "—";
	if (value !== 0 && Math.abs(value) < .001) return `${value.toExponential(2)} ${unit}`;
	return `${formatFixed(value, digits)} ${unit}`;
}
function formatAgreement(relativeError) {
	const percent = relativeError * 100;
	if (percent !== 0 && Math.abs(percent) < 1e-4) return `${percent.toExponential(2)}%`;
	return `${formatFixed(percent, 6)}%`;
}
function nearestFrameIndex(frames, timeS) {
	let best = 0;
	let bestDist = Infinity;
	for (let i = 0; i < frames.length; i++) {
		const dist = Math.abs(frames[i].timeS - timeS);
		if (dist < bestDist) {
			best = i;
			bestDist = dist;
		}
	}
	return best;
}
function Channel({ label, value, unit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0 border-t border-border py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs tracking-widest text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 font-mono text-base tabular-nums text-fg",
			children: [value, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1.5 text-xs tracking-normal text-muted normal-case",
				children: unit
			})]
		})]
	});
}
function Meter({ label, right, fraction }) {
	const width = Math.max(0, Math.min(100, fraction * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-baseline justify-between gap-3 text-xs tracking-widest text-muted uppercase",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-sm tracking-normal text-fg normal-case tabular-nums",
			children: right
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-surface-2",
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-primary",
			style: { width: `${width}%` }
		})
	})] });
}
function AresInstrument() {
	const [body, setBody] = (0, import_react.useState)("earth");
	const [origin, setOrigin] = (0, import_react.useState)("surface");
	const [mode, setMode] = (0, import_react.useState)("earth");
	const [program, setProgram] = (0, import_react.useState)("vertical");
	const [engine, setEngine] = (0, import_react.useState)("burn");
	const [coast, setCoast] = (0, import_react.useState)("numerical");
	const [terminal, setTerminal] = (0, import_react.useState)("off");
	const [horizontal, setHorizontal] = (0, import_react.useState)(0);
	const [guidance, setGuidance] = (0, import_react.useState)("fixed");
	const [entrySpeed, setEntrySpeed] = (0, import_react.useState)(6e3);
	const [entryPropellant, setEntryPropellant] = (0, import_react.useState)(5e4);
	const [entryGamma, setEntryGamma] = (0, import_react.useState)(-12);
	const [substeps, setSubsteps] = (0, import_react.useState)(1);
	const [index, setIndex] = (0, import_react.useState)("end");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [chartReady, setChartReady] = (0, import_react.useState)(false);
	const playRef = (0, import_react.useRef)(null);
	const vacuumSeal = (0, import_react.useMemo)(() => runVerticalBurn(true, substeps), [substeps]);
	const report = (0, import_react.useMemo)(() => {
		const vacuum = mode === "vacuum";
		if (body === "mars") {
			if (origin === "entry") {
				const entryState = marsEntryOrDefault(entrySpeed, entryPropellant, entryGamma);
				const tuned = entryState !== MARS_ENTRY_INTERFACE;
				if (terminal === "default" || terminal === "early") {
					const profile = terminal === "early" ? EARLY_TERMINAL_SEQUENCE : DEFAULT_TERMINAL_SEQUENCE;
					if (guidance === "proportional") {
						const config = {
							...profile,
							guidanceMode: "Proportional"
						};
						return tuned ? runMarsTerminalLanding(vacuum, substeps, config, entryState) : runMarsTerminalLanding(vacuum, substeps, config);
					}
					if (horizontal > 0) {
						const config = {
							...profile,
							horizontalFraction: horizontal
						};
						return tuned ? runMarsTerminalLanding(vacuum, substeps, config, entryState) : runMarsTerminalLanding(vacuum, substeps, config);
					}
					return tuned ? runMarsTerminalLanding(vacuum, substeps, profile, entryState) : runMarsTerminalLanding(vacuum, substeps, profile);
				}
				return tuned ? runMarsEntry(vacuum, substeps, coast === "kepler", 300, entryState) : runMarsEntry(vacuum, substeps, coast === "kepler");
			}
			return runMarsVerticalBurn(vacuum, substeps);
		}
		const guided = program === "pitch" ? DEFAULT_PITCH_PROGRAM : PURE_VERTICAL_PROGRAM;
		if (coast === "kepler") return runKeplerCoast(vacuum, substeps, guided, engine === "cutoff" ? CUTOFF_AT_60_S : {
			tCutoffS: null,
			propellantRemainingKg: null
		}, engine === "cutoff" ? 120 : 90);
		if (engine === "cutoff") return runCoastBurn(vacuum, substeps, guided, CUTOFF_AT_60_S, 120);
		if (program === "pitch") return runPitchedBurn(vacuum, substeps, DEFAULT_PITCH_PROGRAM);
		if (vacuum) return vacuumSeal;
		return runVerticalBurn(false, substeps);
	}, [
		body,
		coast,
		engine,
		entryGamma,
		entryPropellant,
		entrySpeed,
		guidance,
		horizontal,
		mode,
		origin,
		program,
		substeps,
		terminal,
		vacuumSeal
	]);
	const frameIndex = index === "end" ? report.frames.length - 1 : Math.min(index, report.frames.length - 1);
	const frame = report.frames[frameIndex] ?? report.frames[report.frames.length - 1];
	const chartData = (0, import_react.useMemo)(() => report.frames.map((sample) => ({
		t: sample.timeS,
		altKm: sample.altitudeM / 1e3,
		speed: sample.speedMps
	})), [report]);
	const activeSample = report.samples.reduce((best, sample) => sample.timeS <= frame.timeS + 1e-9 ? sample : best, report.samples[0]);
	(0, import_react.useEffect)(() => {
		setChartReady(true);
		return () => {
			if (playRef.current !== null) cancelAnimationFrame(playRef.current);
		};
	}, []);
	function stopPlayback() {
		if (playRef.current !== null) cancelAnimationFrame(playRef.current);
		playRef.current = null;
	}
	function replay() {
		stopPlayback();
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const last = report.frames.length - 1;
		if (reduce) {
			setIndex("end");
			return;
		}
		const started = performance.now();
		const tick = (now) => {
			const u = Math.min(1, (now - started) / 8e3);
			setIndex(Math.round(u * last));
			if (u < 1) playRef.current = requestAnimationFrame(tick);
			else playRef.current = null;
		};
		playRef.current = requestAnimationFrame(tick);
	}
	async function copyLog() {
		try {
			await navigator.clipboard.writeText(report.logText);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	}
	const tw = frame.totalMassKg > 0 && frame.thrustN > 0 ? frame.thrustN / (frame.totalMassKg * G0_MPS2) : 0;
	const mdot = frame.thrustN > 0 ? frame.thrustN / (380 * G0_MPS2) : 0;
	const propellantCapacity = report.samples[0]?.propellantKg ?? 12e5;
	const propellantFraction = propellantCapacity > 0 ? frame.propellantKg / propellantCapacity : 0;
	const achievedShare = report.idealDeltaVMps > 0 ? report.achievedDeltaVMps / report.idealDeltaVMps : 0;
	const terminalLive = body === "mars" && origin === "entry";
	const terminalArmed = terminalLive && terminal !== "off";
	const entryState = marsEntryOrDefault(entrySpeed, entryPropellant, entryGamma);
	const entryTuned = terminalLive && entryState !== MARS_ENTRY_INTERFACE;
	const proportional = terminalArmed && guidance === "proportional";
	const fixedFraction = terminalArmed && !proportional ? report.terminal?.config.horizontalFraction ?? 0 : 0;
	const horizLive = terminalArmed && guidance !== "proportional";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-5xl px-4 py-5 pb-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border pb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-primary uppercase",
							children: proportional || entryTuned ? "Mars GNC · Pass 8" : terminalArmed ? fixedFraction > 0 ? "Mars GNC · Pass 7" : "Mars GNC · Pass 6" : body === "mars" ? "Mars GNC · Pass 5" : report.analyticKepler ? "Mars GNC · Pass 4" : engine === "cutoff" ? "Mars GNC · Pass 3" : program === "pitch" ? "Mars GNC · Pass 2" : "Mars GNC · Pass 1"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-mono text-3xl leading-none text-fg sm:text-4xl",
							children: "ARES CORE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-pretty text-muted",
							children: body === "mars" ? origin === "entry" ? terminal === "default" ? proportional ? "Proportional landing law after the 3 km gate. The share is clamp(horizontal speed / 500 m/s, 0, 0.75) and is held for each 0.02 s step. Throttle stays 60%." : fixedFraction > 0 ? "Terminal sequence armed. Coast to 3 km, flip upright with thrust off, then a 60% burn aimed between local up and the anti-horizontal direction. The aim is held for each 0.02 s step." : "Terminal sequence armed. Coast to 3 km, flip to local vertical in 8 s with thrust off, then a 60% landing burn. Radial speed within 2 m/s and horizontal speed within 0.5 m/s is nominal. Anything faster is a RUD." : terminal === "early" ? proportional ? "Proportional landing law after the 5 km gate, then full thrust. The share is clamp(horizontal speed / 500 m/s, 0, 0.75). A 3.5 km/s, 200 t entry still meets the surface during the 8 s unpowered flip." : fixedFraction > 0 ? "Earlier gate at 5 km, full thrust, with the same scheduled horizontal share on the landing burn. The touchdown gate is unchanged." : "Earlier gate at 5 km, then the same 8 s flip and a 100% vertical burn. The touchdown gate is unchanged. This open-loop burn does not cancel horizontal speed." : entryTuned ? `Entry ${formatFixed(entrySpeed, 0)} m/s at ${formatFixed(entryGamma, 1)}°, ${formatFixed(entryPropellant, 0)} kg. Altitude stays 125 km. Engines stay off until a terminal sequence is armed.` : mode === "vacuum" ? "Entry interface with gravity and atmosphere off. 6 km/s at −12° holds a straight line. Engines stay off." : coast === "kepler" ? "125 km, 6,000 m/s, −12°. Engines off. After the capture instant the arc is drag-free Kepler and specific energy stays constant." : "125 km, 6,000 m/s, −12°, 50 t of propellant left. Engines off for 300 s. Numerical coast keeps the exponential Mars atmosphere." : coast === "kepler" ? "Kepler coast is armed, but the surface engine is still burning, so this run stays on RK4." : mode === "vacuum" ? "Mars selected with gravity and atmosphere off. Pure +Y thrust for 60 seconds." : "Mars surface. μ = 4.282837×10¹³ m³/s², ρ = 0.020 exp(−h / 11,100). Pure +Y thrust for 60 seconds. J2 is off." : report.analyticKepler ? program === "pitch" ? "Cutoff at 60 s, then a drag-free Kepler arc to 120 s. Horizontal speed and flight-path angle follow the captured orbit. Energy stays constant." : mode === "vacuum" ? "Cutoff at 60 s. With gravity off the analytic step is a straight line at constant speed." : "Cutoff at 60 s on the verified Earth burn, then universal-variable Kepler to 120 s. Drag is zero after the element capture." : engine === "cutoff" ? program === "pitch" ? "Pitch-over, then cutoff at 60 s. Coast to 120 s. Horizontal speed remains after the engine stops." : mode === "vacuum" ? "Cutoff at 60 s with gravity and atmosphere off. The coast is a straight constant-velocity line." : "Cutoff at 60 s. Thrust and mass flow stop. Coast to 120 s under gravity and drag." : program === "pitch" ? mode === "vacuum" ? "Pitch program with gravity and atmosphere off. Thrust stays +Y for 20 s, then leaves it at 1.0 deg/s." : "Open-loop pitch: inertial +Y for 20 s, then 1.0 deg/s toward +X. No attitude dynamics." : coast === "kepler" ? "Kepler coast is armed, but thrust is still commanded, so this run stays on the verified RK4 burn." : mode === "vacuum" ? "Gravity and atmosphere are off. Inertial speed must match the ideal rocket equation within 0.1%." : "Sea-level Earth, point-mass gravity, exponential air. 100% thrust along inertial +Y for 90 seconds."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: clsx("shrink-0 rounded-md border px-3 py-2 text-right", vacuumSeal.vacuumCheckPassed ? "border-primary" : "border-border"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Vacuum seal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 font-mono text-lg tabular-nums text-fg",
								children: formatAgreement(vacuumSeal.relativeError)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs tracking-widest text-primary uppercase",
								children: [vacuumSeal.vacuumCheckPassed ? "Pass" : "Fail", " · 0.1% limit"]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 flex flex-col gap-4 sm:flex-row sm:flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-48",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Body"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Primary body",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "earth",
								onClick: () => setBody("earth"),
								children: "Earth"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars",
								onClick: () => setBody("mars"),
								children: "Mars"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Start"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Initial state",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars" && origin === "surface",
								disabled: body !== "mars",
								onClick: () => setOrigin("surface"),
								children: "Surface"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars" && origin === "entry",
								disabled: body !== "mars",
								onClick: () => setOrigin("entry"),
								children: "Entry"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-72",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Terminal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Terminal sequence",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: !terminalLive || terminal === "off",
									disabled: !terminalLive,
									onClick: () => setTerminal("off"),
									children: "Off"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: terminalLive && terminal === "default",
									disabled: !terminalLive,
									onClick: () => setTerminal("default"),
									children: "3 km"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: terminalLive && terminal === "early",
									disabled: !terminalLive,
									onClick: () => setTerminal("early"),
									children: "5 km"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-56",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Horiz"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Landing horizontal fraction",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: !horizLive || horizontal === 0,
									disabled: !horizLive,
									onClick: () => setHorizontal(0),
									children: "0"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: horizLive && horizontal === .3,
									disabled: !horizLive,
									onClick: () => setHorizontal(.3),
									children: "0.3"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: horizLive && horizontal === .6,
									disabled: !horizLive,
									onClick: () => setHorizontal(.6),
									children: "0.6"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-48",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Guidance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Landing guidance",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: !terminalArmed || guidance === "fixed",
								disabled: !terminalArmed,
								onClick: () => setGuidance("fixed"),
								children: "Fixed"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: terminalArmed && guidance === "proportional",
								disabled: !terminalArmed,
								onClick: () => setGuidance("proportional"),
								children: "Prop"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Entry"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Entry interface preset",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: !terminalLive || !entryTuned,
								disabled: !terminalLive,
								onClick: () => {
									setEntrySpeed(6e3);
									setEntryPropellant(5e4);
									setEntryGamma(-12);
								},
								children: "6 km/s"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: terminalLive && entrySpeed === 3500 && entryPropellant === 2e5 && entryGamma === -12,
								disabled: !terminalLive,
								onClick: () => {
									setEntrySpeed(3500);
									setEntryPropellant(2e5);
									setEntryGamma(-12);
								},
								children: "3.5 km/s"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Speed m/s",
						value: entrySpeed,
						disabled: !terminalLive,
						onCommit: (next) => {
							if (next > 0 && next <= 12e3) setEntrySpeed(next);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Propellant kg",
						value: entryPropellant,
						disabled: !terminalLive,
						onCommit: (next) => {
							if (next >= 0 && next <= 2e6) setEntryPropellant(next);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Gamma deg",
						value: entryGamma,
						disabled: !terminalLive,
						onCommit: (next) => {
							if (next >= -90 && next <= 90) setEntryGamma(next);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Environment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Environment",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: mode === "earth",
								onClick: () => setMode("earth"),
								children: body === "mars" ? "Mars" : "Earth"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: mode === "vacuum",
								onClick: () => setMode("vacuum"),
								children: "Vacuum"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-56",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Thrust program"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Thrust program",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars" ? origin === "surface" : program === "vertical",
								disabled: body === "mars",
								onClick: () => setProgram("vertical"),
								children: "Vertical"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars" ? false : program === "pitch",
								disabled: body === "mars",
								onClick: () => setProgram("pitch"),
								children: "1°/s"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-52",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Engine"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Engine cutoff",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars" ? origin === "surface" : engine === "burn",
								disabled: body === "mars",
								onClick: () => setEngine("burn"),
								children: "Burn"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: body === "mars" ? false : engine === "cutoff",
								disabled: body === "mars",
								onClick: () => setEngine("cutoff"),
								children: "Cut 60 s"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "Coast"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "Coast propagator",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: terminalArmed ? true : coast === "numerical",
								disabled: terminalArmed,
								onClick: () => setCoast("numerical"),
								children: "Numerical"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: terminalArmed ? false : coast === "kepler",
								disabled: terminalArmed,
								onClick: () => setCoast("kepler"),
								children: "Kepler"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs tracking-widest text-muted uppercase",
							children: "RK4 sub-steps"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-px overflow-hidden rounded-md border border-border bg-border",
							role: "radiogroup",
							"aria-label": "RK4 sub-steps",
							children: [
								1,
								4,
								20
							].map((count) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
								active: substeps === count,
								onClick: () => setSubsteps(count),
								children: `${count}×`
							}, count))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Mission elapsed"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 font-mono text-3xl tabular-nums text-fg",
								children: ["T+ ", formatMet(frame.timeS)]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs tracking-widest text-primary uppercase",
									children: "Engine on"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-mono text-sm tabular-nums text-fg",
									children: frame.sequencePhase ? frame.impactFlag === "nominal" ? "Touchdown · nominal" : frame.impactFlag === "RUD" ? "Touchdown · RUD" : frame.sequencePhase === "LandingBurn" ? proportional ? `Prop · hf ${formatFixed(frame.horizontalFraction ?? 0, 2)}` : fixedFraction > 0 ? `Aim · ${formatFixed(frame.thrustPitchFromVerticalDeg ?? 0, 1)}° off up` : `Vertical · ${formatFixed(frame.thrustN / 15e6 * 100, 0)}%` : frame.sequencePhase === "Flip" ? `Flip · ${formatFixed(frame.thrustPitchFromVerticalDeg ?? 0, 1)}° from up` : frame.sequencePhase === "Complete" ? "Sequence complete" : "Coast · thrust 0" : frame.engineState === 0 ? "Cutoff · thrust 0" : frame.thrustPitchDeg === 0 ? "+Y · 100%" : `${formatFixed(frame.thrustPitchDeg, 2)}° from +Y`
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs tracking-widest text-muted uppercase",
									children: "Altitude"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-mono text-4xl leading-none tabular-nums text-fg sm:text-5xl",
									children: formatFixed(frame.altitudeM, 1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 text-sm text-muted",
									children: frame.impactFlag ? "impact altitude clamped at the spherical surface" : "meters above the spherical surface"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs tracking-widest text-muted uppercase",
									children: "Inertial speed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-mono text-2xl tabular-nums text-fg",
									children: formatFixed(frame.speedMps, 2)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted",
									children: "m/s"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs tracking-widest text-muted uppercase",
									children: frame.sequencePhase ? "Radial" : "Vertical"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-mono text-2xl tabular-nums text-fg",
									children: formatFixed(frame.sequencePhase ? frame.radialMps ?? 0 : frame.verticalMps, 2)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted",
									children: frame.sequencePhase ? "m/s · up" : "m/s · +Y"
								})
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Propellant remaining",
								right: `${formatFixed(frame.propellantKg, 0)} kg`,
								fraction: propellantFraction
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: terminalArmed ? proportional ? terminal === "early" ? "Mars terminal · 5 km · proportional" : "Mars terminal · 3 km · proportional" : fixedFraction > 0 ? terminal === "early" ? `Mars terminal · 5 km · hf ${formatFixed(fixedFraction, 1)}` : `Mars terminal · 3 km · 60% · hf ${formatFixed(fixedFraction, 1)}` : terminal === "early" ? "Mars terminal · 5 km · 100%" : "Mars terminal · 3 km · 60%" : body === "mars" ? origin === "entry" ? report.disableGravityAndAtmosphere ? "Mars entry · vacuum · 300 s" : report.analyticKepler ? "Mars entry · Kepler · 300 s" : "Mars entry · numerical · 300 s" : report.disableGravityAndAtmosphere ? "Mars vacuum · vertical 60 s" : "Mars surface · vertical 60 s" : report.analyticKepler ? report.pitchProgram ? "Kepler coast · pitched cutoff" : "Kepler coast · vertical cutoff" : report.cutoff ? report.pitchProgram ? "Pitched cutoff · coast 120 s" : "Cutoff 60 s · coast 120 s" : report.pitchProgram ? report.disableGravityAndAtmosphere ? "Pitched vacuum · 90 s" : "Pitched Earth · 90 s" : report.disableGravityAndAtmosphere ? "Vacuum check · 90 s" : "Earth burn · 90 s"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl text-fg",
							children: "Delta-v closure"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-1 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeltaRow, {
									label: "Ideal rocket",
									value: formatFixed(report.idealDeltaVMps, 3),
									unit: "m/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeltaRow, {
									label: "Integrated thrust",
									value: formatFixed(report.thrustIntegratedDeltaVMps, 3),
									unit: "m/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeltaRow, {
									label: "Inertial |Δv|",
									value: formatFixed(report.achievedDeltaVMps, 3),
									unit: "m/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeltaRow, {
									label: "Ideal − inertial",
									value: formatTiny(report.differenceMps, 3, "m/s").replace(/ m\/s$/, ""),
									unit: "m/s"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Inertial share of ideal",
								right: formatFixed(Math.min(achievedShare, 1) * 100, 2) + "%",
								fraction: achievedShare
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-pretty text-muted",
							children: terminalArmed ? report.terminal?.impact ? `Impact ${report.terminal.impact.flag}. Radial ${formatFixed(report.terminal.impact.verticalMps, 1)} m/s, horizontal ${formatFixed(report.terminal.impact.horizontalMps, 1)} m/s, kinetic energy ${report.terminal.impact.kineticEnergyJ.toExponential(3)} J. The impact altitude is clamped at 0.${proportional ? " The landing fraction follows horizontal speed." : fixedFraction > 0 ? ` Landing fraction ${formatFixed(fixedFraction, 1)} opposes horizontal velocity.` : ""}` : "The sequence reached the time limit without meeting the spherical surface." : body === "mars" ? origin === "entry" ? report.analyticKepler ? "Engines are off from the interface. Semi-major axis and eccentricity freeze at capture. Drag, density, and dynamic pressure are zero on the Kepler arc." : report.disableGravityAndAtmosphere ? "No thrust, no gravity, no air. Speed stays 6,000 m/s and the flight-path angle stays −12°." : "No thrust. Altitude falls under Mars gravity. Density follows ρ0 exp(−h / H) while the vehicle is still above the surface." : "Ideal minus inertial speed is Mars gravity and drag. Integrated thrust still matches the rocket equation. μ/R² is about 3.73 m/s²." : report.analyticKepler ? "After cutoff the state is a two-body arc. Semi-major axis and eccentricity are frozen at capture. Drag, density, and dynamic pressure are zero on that arc even if Earth air is selected." : report.cutoff ? "Thrust and mass flow are zero after cutoff. Ideal Δv uses only the propellant burned before cutoff. Integrated thrust stops with the engine." : report.pitchProgram ? "Ideal minus inertial speed includes gravity, drag, and the turn. Integrated thrust is still the rocket-equation impulse." : report.disableGravityAndAtmosphere ? `Inertial speed agrees with Isp·g0·ln(m0/mf) to ${formatAgreement(report.relativeError)}. Limit is 0.100%.` : `Ideal minus inertial speed is the gravity and drag loss. Integrated thrust still matches the rocket equation, because mass flow does not depend on the trajectory.`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs tracking-widest text-primary uppercase",
							children: terminalArmed ? report.terminal?.impact?.flag === "nominal" ? "Verdict · nominal touchdown" : report.terminal?.impact ? "Verdict · RUD" : "Verdict · no impact" : body === "mars" ? origin === "entry" ? report.analyticKepler ? "Verdict · analytic Kepler" : "Verdict · Mars entry" : "Verdict · Mars surface burn" : report.analyticKepler ? "Verdict · analytic Kepler" : report.cutoff ? "Verdict · cutoff and coast" : report.pitchProgram ? "Verdict · open-loop pitch" : report.vacuumCheckApplies ? report.vacuumCheckPassed ? "Verdict · pass" : "Verdict · fail" : "Verdict · gravity and drag loss"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-md border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs tracking-widest text-muted uppercase",
							htmlFor: "burn-scrub",
							children: "Scrub the burn"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: replay,
							className: "inline-flex h-11 items-center gap-2 rounded-md border border-border bg-bg px-3 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Replay"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "burn-scrub",
						type: "range",
						min: 0,
						max: Math.max(0, report.frames.length - 1),
						step: 1,
						value: frameIndex,
						"aria-valuetext": `T+ ${formatMet(frame.timeS)}`,
						onChange: (event) => {
							stopPlayback();
							setIndex(Number(event.target.value));
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between font-mono text-xs tabular-nums text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTick(0) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTick(report.endTimeS / 2) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTick(report.endTimeS) })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 grid gap-4 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,0.85fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm tracking-widest text-muted uppercase",
								children: "Trajectory"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3 font-mono text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "Altitude km"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-fg",
									children: "Speed m/s"
								})]
							})]
						}),
						chartReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BurnChart, {
							data: chartData,
							timeS: frame.timeS
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-52 items-end border-b border-border text-sm text-muted",
							children: "Altitude and speed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid min-w-0 grid-cols-2 gap-x-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Acceleration",
									value: formatFixed(frame.accelMps2, 3),
									unit: "m/s²"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Gravity",
									value: formatFixed(frame.gravityMps2, 4),
									unit: "m/s²"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Thrust",
									value: formatFixed(frame.thrustN, 0),
									unit: "N"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Drag",
									value: formatFixed(frame.dragN, 1),
									unit: "N"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Dynamic pressure",
									value: formatFixed(frame.dynamicPressurePa, 1),
									unit: "Pa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Density",
									value: formatDensity(frame.densityKgM3),
									unit: "kg/m³"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Body",
									value: frame.body,
									unit: "primary"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Mach",
									value: formatFixed(frame.mach, 3),
									unit: frame.body === "Mars" ? "a = 240 m/s" : "a = 340 m/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Mass",
									value: formatFixed(frame.totalMassKg, 1),
									unit: "kg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Mass flow",
									value: formatFixed(mdot, 2),
									unit: "kg/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "T / W₀",
									value: formatFixed(tw, 3),
									unit: "g0"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Propellant",
									value: formatFixed(frame.propellantKg, 1),
									unit: "kg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Horizontal speed",
									value: formatFixed(frame.horizontalMps, 2),
									unit: "m/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Flight-path angle",
									value: formatFixed(frame.flightPathDeg, 2),
									unit: "deg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Thrust pitch",
									value: formatFixed(frame.thrustPitchDeg, 2),
									unit: "deg from +Y"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Radius",
									value: formatFixed(frame.radiusM, 1),
									unit: "m"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Engine state",
									value: frame.engineState === 1 ? "1" : "0",
									unit: frame.engineState === 1 ? "thrusting" : "cutoff"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Since cutoff",
									value: formatFixed(frame.timeSinceCutoffS, 2),
									unit: "s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Specific energy",
									value: frame.specificEnergyM2S2.toExponential(4),
									unit: "m²/s²"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Propagation",
									value: frame.propagationMode === "analytic" ? "Analytic" : "Numerical",
									unit: frame.propagationMode === "analytic" ? "Kepler" : "RK4"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Semi-major axis",
									value: frame.timeSinceElementsS > 0 || frame.semiMajorAxisM !== 0 ? formatAxis(frame.semiMajorAxisM) : "—",
									unit: "m"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Eccentricity",
									value: frame.timeSinceElementsS > 0 || frame.eccentricity !== 0 ? formatFixed(frame.eccentricity, 6) : "—",
									unit: "e"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
									label: "Since elements",
									value: formatFixed(frame.timeSinceElementsS, 2),
									unit: "s"
								}),
								frame.sequencePhase ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Phase",
										value: frame.sequencePhase,
										unit: "terminal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Pitch from vertical",
										value: formatFixed(frame.thrustPitchFromVerticalDeg ?? 0, 2),
										unit: "deg"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Impact",
										value: frame.impactFlag ? frame.impactFlag : "—",
										unit: frame.impactFlag ? "touchdown" : "in flight"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Impact energy",
										value: frame.impactFlag && frame.impactKineticEnergyJ !== void 0 ? frame.impactKineticEnergyJ.toExponential(3) : "—",
										unit: "J"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Peak speed",
										value: formatFixed(frame.peakSpeedMps ?? 0, 1),
										unit: "m/s"
									}),
									proportional ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Guidance",
										value: "Proportional",
										unit: "k · vh / vref"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Horiz fraction",
										value: formatFixed(frame.horizontalFraction ?? 0, 3),
										unit: "commanded"
									})] }) : fixedFraction > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Channel, {
										label: "Horiz fraction",
										value: formatFixed(frame.horizontalFraction ?? 0, 2),
										unit: frame.sequencePhase === "LandingBurn" || frame.impactFlag ? "commanded" : "coast"
									}) : null
								] }) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm tracking-widest text-muted uppercase",
							children: "Five-second log"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: copyLog,
							className: "inline-flex h-11 items-center gap-2 rounded-md border border-border bg-bg px-3 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
								className: "size-4",
								"aria-hidden": "true"
							}), copied ? "Copied" : "Copy"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 max-h-[64rem] overflow-y-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3 font-mono text-xs tracking-widest text-muted uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Met" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Altitude" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Speed" }),
								report.terminal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phase" }) : null
							]
						}), report.samples.map((sample, sampleIndex) => {
							const selected = sample.timeS === activeSample.timeS;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									stopPlayback();
									setIndex(nearestFrameIndex(report.frames, sample.timeS));
								},
								className: clsx("flex min-h-11 w-full items-baseline justify-between gap-3 border-t border-border py-2.5 text-left font-mono text-sm tabular-nums", selected ? "text-primary" : "text-fg"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatMet(sample.timeS) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: selected ? "text-primary" : "text-muted",
										children: [formatFixed(sample.altitudeM, 0), " m"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatFixed(sample.speedMps, 1) }),
									report.terminal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: selected ? "text-primary" : "text-muted",
										children: phaseLabel(sample.sequencePhase)
									}) : null
								]
							}) }, `${sample.timeS}-${sampleIndex}`);
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-md border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm tracking-widest text-muted uppercase",
						children: "Pass 1 model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 grid gap-2 font-mono text-sm text-fg sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "a = g(r) + T/m + D/m" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "g = −μ r / |r|³" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "D = ½ ρ v² Cd A" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ρ = ρ0 exp(−h / H)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ṁ = T / (Isp g0)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Δv = Isp g0 ln(m0 / mf)" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "μ Earth",
								v: "3.986004418×10¹⁴ m³/s²"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "R",
								v: "6,371,000 m"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "ρ0 / H",
								v: "1.225 kg/m³ · 8,500 m"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "Thrust",
								v: "15,000,000 N vac"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "Isp / g0",
								v: "380 s · 9.80665 m/s²"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "Cd / A",
								v: "0.50 · 60 m²"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "Dry mass",
								v: "120,000 kg"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "Propellant",
								v: "1,200,000 kg"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
								k: "Step",
								v: "RK4 · 0.02 s"
							}),
							body === "mars" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
									k: "μ Mars",
									v: "4.282837×10¹³ m³/s²"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
									k: "R Mars",
									v: "3,389,500 m"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
									k: "ρ0 / H Mars",
									v: "0.020 kg/m³ · 11,100 m"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
									k: "Entry",
									v: "125 km · 6,000 m/s · −12°"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
									k: "Entry propellant",
									v: "50,000 kg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
									k: "Sound Mars",
									v: "240 m/s"
								}),
								terminalArmed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "Flip",
										v: "8 s · thrust off"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "Landing thrust",
										v: terminal === "early" ? "100% after 5 km" : "60% after 3 km"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "Nominal",
										v: "|vrad| ≤ 2 · vh ≤ 0.5 m/s"
									}),
									proportional ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "Guidance",
										v: "proportional · k = 1"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "vref / max",
										v: "500 m/s · 0.75"
									})] }) : fixedFraction > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "Horiz fraction",
										v: `${formatFixed(fixedFraction, 1)} · anti-vh`
									}) : null,
									entryTuned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Const, {
										k: "Entry",
										v: `${formatFixed(entrySpeed, 0)} m/s · ${formatFixed(entryPropellant, 0)} kg`
									}) : null
								] }) : null
							] }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-pretty text-muted",
						children: ["No wind, no planetary rotation, no gimbal, no attitude. J2 is implemented and left off for this verification. g0 defines exhaust velocity only. Local gravity is μ/r², about 9.820 m/s² at the surface with these constants. Cutoff sets thrust and mass flow to zero. Numerical coast keeps RK4, including drag on Earth. Analytic Kepler replaces that coast with a universal-variable step and zero drag. The Unity scripts are the same core and do not call PhysX. Leave Analytic Kepler off to reproduce the verified burn numbers.", terminalArmed ? proportional ? " Terminal sequence is open-loop and Mars-entry only. Proportional mode sets the landing-burn horizontal share from current horizontal speed and holds that direction for each 0.02 s step. Fixed mode with fraction 0 keeps the Pass 6 burn." : fixedFraction > 0 ? " Terminal sequence is open-loop and Mars-entry only. The landing burn mixes local up with a share opposing horizontal velocity, held constant across each RK4 step. Set Horiz to 0 to restore the Pass 6 vertical burn." : " Terminal sequence is open-loop and Mars-entry only. The flip slews thrust from anti-velocity to local up, then holds vertical thrust. Impact altitude is clamped at 0. Leave Terminal off to keep the Pass 1–5 numbers." : body === "mars" ? " Mars uses the same integrator. Surface gravity is μ/R², about 3.73 m/s². The entry start does not change any Earth run." : ""]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-md border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm tracking-widest text-muted uppercase",
						children: "Unity drop-in"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "C# 9 for Unity 2022 LTS / 2023 LTS. Namespaces MarsMission.Math and MarsMission.PhysicsCore."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/pass1/AresCore-Pass1.zip",
						download: true,
						className: "inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-medium text-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Download scripts"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid gap-2",
					children: SOURCE_FILES.map((file) => {
						const name = file.split("/").pop() ?? file;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "min-w-0 border-t border-border pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "block min-w-0",
								href: `/pass1/${file}`,
								download: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm text-fg",
									children: name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block font-mono text-xs break-all text-muted",
									children: file
								})]
							})
						}, file);
					})
				})]
			})
		]
	});
}
function formatAxis(value) {
	if (!Number.isFinite(value)) return "inf";
	return formatFixed(value, 0);
}
function phaseLabel(phase) {
	if (phase === "LandingBurn") return "Burn";
	if (phase === "Complete") return "Done";
	return phase ?? "";
}
function NumberField({ label, value, disabled, onCommit }) {
	const [draft, setDraft] = (0, import_react.useState)(String(value));
	(0, import_react.useEffect)(() => {
		setDraft(String(value));
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "min-w-0 sm:w-36",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-2 block text-xs tracking-widest text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "number",
			inputMode: "decimal",
			"aria-label": label,
			disabled,
			value: draft,
			onChange: (event) => setDraft(event.target.value),
			onBlur: () => {
				const next = Number(draft);
				if (Number.isFinite(next)) onCommit(next);
				setDraft(String(value));
			},
			onKeyDown: (event) => {
				if (event.key === "Enter") event.currentTarget.blur();
			},
			className: clsx("h-11 w-full rounded-md border border-border bg-surface px-2 font-mono text-sm text-fg tabular-nums", disabled && "cursor-not-allowed opacity-40")
		})]
	});
}
function ModeButton({ active, onClick, children, disabled = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "radio",
		"aria-checked": active,
		disabled,
		onClick,
		className: clsx("h-11 px-3 text-sm", disabled && "cursor-not-allowed opacity-40", active ? "bg-primary text-bg" : "bg-surface text-fg"),
		children
	});
}
function DeltaRow({ label, value, unit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3 border-t border-border pt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
			className: "font-mono text-base tabular-nums text-fg",
			children: [value, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1.5 text-xs text-muted",
				children: unit
			})]
		})]
	});
}
function Const({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border pt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs tracking-widest text-muted uppercase",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-mono text-sm tabular-nums text-fg",
			children: v
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AresInstrument, {});
}
//#endregion
export { Home as component };
