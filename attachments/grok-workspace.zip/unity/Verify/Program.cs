using System;
using MarsMission.Math;
using MarsMission.PhysicsCore;

internal static class Program
{
    private static int Main()
    {
        SimulationReport vacuum = SimulationHarness.RunVerticalBurn(true, 1);
        SimulationReport earth = SimulationHarness.RunVerticalBurn(false, 1);

        PitchProgram pureVertical = PitchProgram.RateAfterVertical(20d, 0d);
        SimulationReport earthAgain = SimulationHarness.RunPitchedBurn(false, 1, pureVertical);
        SimulationReport vacuumAgain = SimulationHarness.RunPitchedBurn(true, 1, pureVertical);

        SimulationReport pitched = SimulationHarness.RunPitchedBurn(false, 1, PitchProgram.DefaultPitchOver());
        TelemetrySample at20 = pitched.Samples[4];
        TelemetrySample at90 = pitched.Samples[18];

        bool caseA = vacuum.VacuumCheckPassed
            && vacuumAgain.VacuumCheckPassed
            && earth.DifferenceMps > 0d
            && earth.Samples.Count == 19
            && earth.AchievedDeltaVMps == earthAgain.AchievedDeltaVMps
            && vacuum.AchievedDeltaVMps == vacuumAgain.AchievedDeltaVMps
            && earth.Samples[18].AltitudeM == earthAgain.Samples[18].AltitudeM
            && earth.Samples[18].HorizontalMps == 0d
            && earth.Samples[18].ThrustPitchDeg == 0d;

        bool caseB = at20.TimeS == 20d
            && at20.HorizontalMps == 0d
            && at20.ThrustPitchDeg == 0d
            && at20.AltitudeM == earth.Samples[4].AltitudeM
            && Math.Abs(pitched.Samples[5].ThrustPitchDeg - 5d) < 1e-12d
            && Math.Abs(at90.ThrustPitchDeg - 70d) < 1e-12d
            && at90.HorizontalMps > 1d
            && at90.FlightPathDeg < 89d
            && at90.FlightPathDeg < at20.FlightPathDeg;

        SimulationReport verticalAgain = SimulationHarness.RunCoastBurn(
            false, 1, PitchProgram.PureVertical(), CutoffCommand.AtTime(120d), 90d);
        SimulationReport pitchedAgain = SimulationHarness.RunCoastBurn(
            false, 1, PitchProgram.DefaultPitchOver(), CutoffCommand.Never(), 90d);
        SimulationReport cutoff = SimulationHarness.RunCoastBurn(
            false, 1, PitchProgram.PureVertical(), CutoffCommand.AtTime(60d), 120d);
        SimulationReport pitchedCutoff = SimulationHarness.RunCoastBurn(
            false, 1, PitchProgram.DefaultPitchOver(), CutoffCommand.AtTime(60d), 120d);

        TelemetrySample cut60 = cutoff.Samples[12];
        TelemetrySample cut120 = cutoff.Samples[24];
        bool caseCutoff = verticalAgain.AchievedDeltaVMps == earth.AchievedDeltaVMps
            && verticalAgain.Samples[18].AltitudeM == earth.Samples[18].AltitudeM
            && pitchedAgain.AchievedDeltaVMps == pitched.AchievedDeltaVMps
            && cutoff.Samples.Count == 25
            && cut60.AltitudeM == earth.Samples[12].AltitudeM
            && cut60.PropellantKg == earth.Samples[12].PropellantKg
            && cut60.ThrustN == 0d
            && cut120.PropellantKg == cut60.PropellantKg
            && cut120.EngineState == 0d
            && cut120.TimeSinceCutoffS == 60d
            && pitchedCutoff.Samples[12].HorizontalMps == pitched.Samples[12].HorizontalMps
            && pitchedCutoff.Samples[24].HorizontalMps > 1d
            && pitchedCutoff.Samples[24].PropellantKg == pitchedCutoff.Samples[12].PropellantKg;

        bool pass = caseA && caseB && caseCutoff;
        if (!pass)
        {
            Console.WriteLine("VERIFY FAIL");
            return 1;
        }

        SimulationReport delegated = SimulationHarness.RunKeplerCoast(
            false, 1, PitchProgram.PureVertical(), CutoffCommand.Never(), 90d);
        SimulationReport analytic = SimulationHarness.RunKeplerCoast(
            false, 1, PitchProgram.PureVertical(), CutoffCommand.AtTime(60d), 120d);
        SimulationReport pitchedAnalytic = SimulationHarness.RunKeplerCoast(
            false, 1, PitchProgram.DefaultPitchOver(), CutoffCommand.AtTime(60d), 120d);

        bool caseOff = delegated.AnalyticKepler == false
            && delegated.AchievedDeltaVMps == earth.AchievedDeltaVMps
            && delegated.Samples[18].AltitudeM == earth.Samples[18].AltitudeM
            && delegated.Samples[18].HorizontalMps == 0d
            && Math.Abs(earth.AchievedDeltaVMps - 296.123d) < 0.001d
            && Math.Abs(earth.Samples[18].AltitudeM - 10800.316d) < 0.01d;

        KeplerCapture cap = analytic.KeplerCapture;
        VehicleState vac90 = VacuumCoast(cap, 30d);
        VehicleState vac120 = VacuumCoast(cap, 60d);
        TelemetrySample a90 = analytic.Samples[18];
        TelemetrySample a120 = analytic.Samples[24];
        bool caseKepler = analytic.AnalyticKepler
            && analytic.Samples[12].AltitudeM == cut60.AltitudeM
            && analytic.Samples[12].SpeedMps == cut60.SpeedMps
            && analytic.Samples[12].PropellantKg == cut60.PropellantKg
            && Math.Abs(analytic.Samples[12].PropellantKg - 958488.265d) < 0.001d
            && a90.PropagationMode == "analytic"
            && a90.DragN == 0d
            && a120.DragN == 0d
            && a120.TimeSinceElementsS == 60d
            && Math.Abs(a90.RadiusM - vac90.Position.Magnitude) < 1d
            && Math.Abs(a120.RadiusM - vac120.Position.Magnitude) < 1d
            && Math.Abs(a90.SpeedMps - vac90.Velocity.Magnitude) < 0.01d
            && Math.Abs(a120.SpeedMps - vac120.Velocity.Magnitude) < 0.01d;

        TelemetrySample p60 = pitchedAnalytic.Samples[12];
        TelemetrySample p120 = pitchedAnalytic.Samples[24];
        bool casePitchKepler = pitchedAnalytic.AnalyticKepler
            && p60.HorizontalMps == pitchedCutoff.Samples[12].HorizontalMps
            && p60.HorizontalMps > 1d
            && p120.HorizontalMps > 1d
            && p120.DragN == 0d
            && p120.PropellantKg == p60.PropellantKg
            && Math.Abs(p120.SpecificEnergyM2S2 - pitchedAnalytic.Samples[18].SpecificEnergyM2S2) < 1e-4d
            && Math.Abs(p120.FlightPathDeg - p60.FlightPathDeg) > 0.1d;

        Vector3d circR = new Vector3d(EARTH_CHECK_RADIUS, 0d, 0d);
        double circV = Math.Sqrt(EARTH_CHECK_MU / EARTH_CHECK_RADIUS);
        Vector3d circVel = new Vector3d(0d, circV, 0d);
        KeplerElements circ = KeplerPropagator.Elements(circR, circVel, EARTH_CHECK_MU);
        double period = 2d * Math.PI * Math.Sqrt(EARTH_CHECK_RADIUS * EARTH_CHECK_RADIUS * EARTH_CHECK_RADIUS / EARTH_CHECK_MU);
        KeplerState back = KeplerPropagator.Propagate(circR, circVel, EARTH_CHECK_MU, period);
        bool caseOrbit = Math.Abs(circ.SemiMajorAxisM - EARTH_CHECK_RADIUS) < 1e-4d
            && circ.Eccentricity < 1e-10d
            && (back.Position - circR).Magnitude < 1e-3d;

        pass = caseOff && caseKepler && casePitchKepler && caseOrbit;

        SimulationReport marsBurn = SimulationHarness.RunMarsVerticalBurn(false, 1, 60d);
        double marsG = PlanetaryEnvironment.MarsMuM3S2
            / (PlanetaryEnvironment.MarsEquatorialRadiusM * PlanetaryEnvironment.MarsEquatorialRadiusM);
        bool caseMarsBurn = Math.Abs(marsG - 3.71d) < 0.03d
            && marsBurn.Samples.Count == 13
            && marsBurn.Samples[0].Body == "Mars"
            && marsBurn.Samples[0].AltitudeM == 0d
            && marsBurn.Samples[12].TimeS == 60d
            && marsBurn.Samples[12].HorizontalMps == 0d
            && marsBurn.Samples[12].AltitudeM > marsBurn.Samples[6].AltitudeM
            && marsBurn.Samples[12].DensityKgM3 > 0d
            && marsBurn.Samples[12].DensityKgM3 < marsBurn.Samples[0].DensityKgM3
            && Math.Abs(earth.AchievedDeltaVMps - 296.123d) < 0.001d;

        SimulationReport marsEntry = SimulationHarness.RunMarsEntry(false, false);
        bool densityRose = false;
        for (int i = 1; i < marsEntry.Samples.Count; i++)
        {
            TelemetrySample prev = marsEntry.Samples[i - 1];
            TelemetrySample next = marsEntry.Samples[i];
            if (next.AltitudeM > 0d && next.AltitudeM < prev.AltitudeM && next.DensityKgM3 > prev.DensityKgM3)
                densityRose = true;
        }

        SimulationReport marsAnalytic = SimulationHarness.RunMarsEntry(false, true);
        double entryEnergy = marsAnalytic.Samples[1].SpecificEnergyM2S2;
        bool caseMarsEntry = marsEntry.Samples.Count == 61
            && marsEntry.Samples[0].AltitudeM == 125_000d
            && Math.Abs(marsEntry.Samples[0].SpeedMps - 6_000d) < 1e-6d
            && Math.Abs(marsEntry.Samples[0].FlightPathDeg - (-12d)) < 1e-6d
            && marsEntry.Samples[0].PropellantKg == 50_000d
            && marsEntry.Samples[0].ThrustN == 0d
            && marsEntry.Samples[1].AltitudeM < marsEntry.Samples[0].AltitudeM
            && marsEntry.Samples[6].SpeedMps != marsEntry.Samples[0].SpeedMps
            && densityRose
            && marsAnalytic.AnalyticKepler
            && marsAnalytic.Samples[1].DragN == 0d
            && marsAnalytic.Samples[1].DensityKgM3 == 0d
            && Math.Abs(marsAnalytic.Samples[60].SpecificEnergyM2S2 - entryEnergy) < 1e-6d * Math.Abs(entryEnergy);

        pass = pass && caseMarsBurn && caseMarsEntry;

        SimulationReport terminal = SimulationHarness.RunMarsTerminalLanding(false, false);
        SimulationReport terminalEarly = SimulationHarness.RunMarsTerminalLanding(false, true);
        bool sawFlip = false;
        bool sawBurn = false;
        double flipAltitude = -1d;
        double burnThrust = -1d;
        for (int i = 0; i < terminal.Samples.Count; i++)
        {
            if (!sawFlip && terminal.Samples[i].SequencePhase == "Flip")
            {
                sawFlip = true;
                flipAltitude = terminal.Samples[i].AltitudeM;
            }
            if (!sawBurn && terminal.Samples[i].SequencePhase == "LandingBurn")
            {
                sawBurn = true;
                burnThrust = terminal.Samples[i].ThrustN;
            }
        }
        TelemetrySample terminalLast = terminal.Samples[terminal.Samples.Count - 1];
        bool caseTerminal = sawFlip
            && sawBurn
            && flipAltitude <= 3_000d
            && flipAltitude > 2_500d
            && Math.Abs(burnThrust - 0.6d * 15_000_000d) < 1d
            && terminalLast.AltitudeM == 0d
            && (terminal.ImpactFlag == "RUD" || terminal.ImpactFlag == "nominal")
            && terminalEarly.Samples[0].SequencePhase == "Coast"
            && terminalEarly.TriggerTimeS < terminal.TriggerTimeS
            && Math.Abs(earth.AchievedDeltaVMps - 296.123d) < 0.001d;

        pass = pass && caseTerminal;

        TerminalSequence tilt = new TerminalSequence(
            TerminalSequence.DefaultTriggerAltitudeM,
            null,
            TerminalSequence.DefaultFlipDurationS,
            TerminalSequence.DefaultFlipThrottle,
            TerminalSequence.DefaultLandingThrottle,
            null,
            0.3d);
        TerminalSequence wider = new TerminalSequence(
            TerminalSequence.DefaultTriggerAltitudeM,
            null,
            TerminalSequence.DefaultFlipDurationS,
            TerminalSequence.DefaultFlipThrottle,
            TerminalSequence.DefaultLandingThrottle,
            null,
            0.6d);
        SimulationReport caseB = SimulationHarness.RunMarsTerminalLanding(false, 1, tilt);
        SimulationReport caseC = SimulationHarness.RunMarsTerminalLanding(false, 1, wider);
        bool caseHorizontal = caseB.ImpactHorizontalMps < terminal.ImpactHorizontalMps
            && caseC.ImpactHorizontalMps < caseB.ImpactHorizontalMps
            && (caseB.ImpactFlag == "RUD" || caseB.ImpactFlag == "nominal")
            && (caseC.ImpactFlag == "RUD" || caseC.ImpactFlag == "nominal")
            && Math.Abs(earth.AchievedDeltaVMps - 296.123d) < 0.001d;
        pass = pass && caseHorizontal;

        TerminalSequence proportional = new TerminalSequence(
            TerminalSequence.DefaultTriggerAltitudeM,
            null,
            TerminalSequence.DefaultFlipDurationS,
            TerminalSequence.DefaultFlipThrottle,
            TerminalSequence.DefaultLandingThrottle,
            null,
            0d,
            "Proportional",
            1d,
            500d,
            0.75d);
        SimulationReport caseProp = SimulationHarness.RunMarsTerminalLanding(false, 1, proportional);
        bool sawGuide = false;
        for (int i = 0; i < caseProp.Samples.Count; i++)
        {
            if (caseProp.Samples[i].SequencePhase == "LandingBurn" && caseProp.Samples[i].GuidanceMode == "Proportional")
                sawGuide = true;
        }
        TerminalSequence heavy = new TerminalSequence(
            TerminalSequence.EarlyTriggerAltitudeM,
            null,
            TerminalSequence.DefaultFlipDurationS,
            TerminalSequence.DefaultFlipThrottle,
            TerminalSequence.EarlyLandingThrottle,
            null,
            0d,
            "Proportional");
        SimulationReport caseHeavy = SimulationHarness.RunMarsTerminalLanding(false, 1, heavy, 125_000d, 3_500d, -12d, 200_000d);
        bool caseProportional = sawGuide
            && caseProp.ImpactHorizontalMps < terminal.ImpactHorizontalMps
            && (caseProp.ImpactFlag == "RUD" || caseProp.ImpactFlag == "nominal")
            && caseHeavy.ImpactFlag == "RUD"
            && caseHeavy.FinalMassKg > 300_000d
            && Math.Abs(earth.AchievedDeltaVMps - 296.123d) < 0.001d;
        pass = pass && caseProportional;
        Console.WriteLine(pass ? "VERIFY PASS" : "VERIFY FAIL");
        if (pass)
        {
            Console.WriteLine("vertical dv " + earth.AchievedDeltaVMps.ToString("F6"));
            Console.WriteLine("vertical alt " + earth.Samples[18].AltitudeM.ToString("F6"));
            Console.WriteLine("prop60 " + analytic.Samples[12].PropellantKg.ToString("F6"));
            Console.WriteLine("kepler90 r " + a90.RadiusM.ToString("F6") + " vac " + vac90.Position.Magnitude.ToString("F6"));
            Console.WriteLine("pitch vh120 " + p120.HorizontalMps.ToString("F6") + " gamma " + p120.FlightPathDeg.ToString("F6"));
        }
        return pass ? 0 : 1;
    }

    private const double EARTH_CHECK_MU = 3.986004418e14d;
    private const double EARTH_CHECK_RADIUS = 6_371_000d + 200_000d;

    private static VehicleState VacuumCoast(KeplerCapture capture, double seconds)
    {
        PlanetaryEnvironment env = PlanetaryEnvironment.CreateEarth(false);
        env.GravityEnabled = true;
        env.AtmosphereEnabled = false;
        IntegratorRK4 integrator = new IntegratorRK4(env, PropulsionModel.CreateDefaultStage());
        VehicleState state = new VehicleState
        {
            Position = capture.Position,
            Velocity = capture.Velocity,
            PropellantMassKg = capture.PropellantKg,
            TotalMassKg = capture.TotalMassKg,
            ThrustIntegratedDeltaVMps = capture.ThrustIntegratedDeltaVMps
        };
        int steps = (int)Math.Round(seconds * IntegratorRK4.StepHz);
        for (int i = 0; i < steps; i++) integrator.Step(state, 1d / IntegratorRK4.StepHz, 1, 0d);
        return state;
    }
}
