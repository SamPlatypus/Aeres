import type { ForceEvaluation } from "./integrator-rk4.ts";
import { flightPathAngleDeg, horizontalSpeedMps } from "./pitch-program.ts";
import { Vector3d } from "./vector3d.ts";

export interface TelemetryFrame {
  timeS: number;
  altitudeM: number;
  speedMps: number;
  verticalMps: number;
  accelMps2: number;
  propellantKg: number;
  totalMassKg: number;
  thrustN: number;
  dynamicPressurePa: number;
  densityKgM3: number;
  dragN: number;
  gravityMps2: number;
  horizontalMps: number;
  flightPathDeg: number;
  thrustPitchDeg: number;
  radiusM: number;
  /** 1 while thrusting, 0 after cutoff. */
  engineState: number;
  /** Seconds after cutoff. 0 while the engine is on, and 0 at the cutoff instant. */
  timeSinceCutoffS: number;
  /** Specific mechanical energy, m²/s². */
  specificEnergyM2S2: number;
  /** Numerical RK4, or analytic Kepler after cutoff. */
  propagationMode: "numerical" | "analytic";
  /** Osculating semi-major axis once a Kepler state is captured. 0 before that. */
  semiMajorAxisM: number;
  eccentricity: number;
  /** Seconds since the Kepler element capture. 0 while still on RK4. */
  timeSinceElementsS: number;
  /** Active primary. Earth on every verified Pass 1–4 frame. */
  body: string;
  /** Speed divided by the body's constant speed of sound. */
  mach: number;
  /** Set only while a terminal sequence is armed. Absent on Pass 1–5 frames. */
  sequencePhase?: "Coast" | "Flip" | "LandingBurn" | "Complete";
  /** Commanded thrust angle from local up. 0 is pure vertical. */
  thrustPitchFromVerticalDeg?: number;
  /** Radial rate, positive outward. Present on terminal-sequence frames. */
  radialMps?: number;
  impactFlag?: "" | "nominal" | "RUD";
  impactKineticEnergyJ?: number;
  impactSpeedMps?: number;
  impactVerticalMps?: number;
  impactHorizontalMps?: number;
  peakSpeedMps?: number;
  /** Landing-burn horizontal fraction. Absent means the Pass 6 vertical burn. */
  horizontalFraction?: number;
  /** Set only while proportional horizontal opposition is commanding the landing burn. */
  guidanceMode?: "Proportional";
}

export function frameFromForce(
  timeS: number,
  velocity: Vector3d,
  position: Vector3d,
  propellantKg: number,
  force: ForceEvaluation,
  thrustPitchDeg: number,
  engineState = 1,
  timeSinceCutoffS = 0,
  specificEnergyM2S2 = 0,
  propagationMode: "numerical" | "analytic" = "numerical",
  semiMajorAxisM = 0,
  eccentricity = 0,
  timeSinceElementsS = 0,
  body = "Earth",
  speedOfSoundMps = 340,
): TelemetryFrame {
  return {
    timeS,
    altitudeM: force.altitudeM,
    speedMps: velocity.magnitude,
    verticalMps: velocity.y,
    accelMps2: force.accelerationMagnitudeMps2,
    propellantKg,
    totalMassKg: force.massKg,
    thrustN: force.thrustN,
    dynamicPressurePa: force.dynamicPressurePa,
    densityKgM3: force.densityKgM3,
    dragN: force.dragN,
    gravityMps2: force.gravityMps2,
    horizontalMps: horizontalSpeedMps(position, velocity),
    flightPathDeg: flightPathAngleDeg(position, velocity),
    thrustPitchDeg,
    radiusM: position.magnitude,
    engineState,
    timeSinceCutoffS,
    specificEnergyM2S2,
    propagationMode,
    semiMajorAxisM,
    eccentricity,
    timeSinceElementsS,
    body,
    mach: speedOfSoundMps > 0 ? velocity.magnitude / speedOfSoundMps : 0,
  };
}

export function formatLogLine(frame: TelemetryFrame): string {
  return [
    `t=${frame.timeS.toFixed(3)} s`,
    `alt=${frame.altitudeM.toFixed(3)} m`,
    `v=${frame.speedMps.toFixed(4)} m/s`,
    `vy=${frame.verticalMps.toFixed(4)} m/s`,
    `a=${frame.accelMps2.toFixed(6)} m/s^2`,
    `mp=${frame.propellantKg.toFixed(3)} kg`,
    `m=${frame.totalMassKg.toFixed(3)} kg`,
    `T=${frame.thrustN.toFixed(1)} N`,
    `Q=${frame.dynamicPressurePa.toFixed(3)} Pa`,
    `rho=${frame.densityKgM3.toFixed(8)} kg/m^3`,
    `D=${frame.dragN.toFixed(3)} N`,
    `g=${frame.gravityMps2.toFixed(6)} m/s^2`,
    `vh=${frame.horizontalMps.toFixed(4)} m/s`,
    `gamma=${frame.flightPathDeg.toFixed(4)} deg`,
    `pitch=${frame.thrustPitchDeg.toFixed(4)} deg`,
    `r=${frame.radiusM.toFixed(3)} m`,
    `eng=${frame.engineState.toFixed(0)}`,
    `tco=${frame.timeSinceCutoffS.toFixed(3)} s`,
    `eps=${frame.specificEnergyM2S2.toExponential(6)} m^2/s^2`,
    `prop=${frame.propagationMode}`,
    `a=${Number.isFinite(frame.semiMajorAxisM) ? frame.semiMajorAxisM.toFixed(3) : "inf"} m`,
    `e=${frame.eccentricity.toFixed(8)}`,
    `tke=${frame.timeSinceElementsS.toFixed(3)} s`,
    `body=${frame.body}`,
    `M=${frame.mach.toFixed(4)}`,
  ].join(" | ");
}
